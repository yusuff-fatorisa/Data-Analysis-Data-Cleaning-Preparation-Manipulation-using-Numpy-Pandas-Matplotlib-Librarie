### Hello, welcome to another lesson. This lesson is in continuation of the series on using Python and its vast Libraries [ Numpy, Pandas, Matplotlib etc ] for Data Analysis Tasks.

### Most importantly, it's about sharing my growth process on this career path, and also to encourage you on what you're doing. Be encouraged and keep doing it, even if it means doing it poorly till you gain mastery of it

### First, you need to import the necessary Libraries required for task execution, then remember to add "%matplotlib inline" for display of plots.

### This dataset is another excel file downloaded from the website of "WHO". It's readily available for the public access

### Import the file and read the first 5 lines of the DataFrame


```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
%matplotlib inline
```


```python
dataset = pd.read_excel("TB Outcomes Completed.xlsx", sheet_name = 0, index_col = 0)
dataset.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>iso2</th>
      <th>iso3</th>
      <th>iso_numeric</th>
      <th>g_whoregion</th>
      <th>year</th>
      <th>rep_meth</th>
      <th>new_sp_coh</th>
      <th>new_sp_cur</th>
      <th>new_sp_cmplt</th>
      <th>new_sp_died</th>
      <th>...</th>
      <th>mdr_coh</th>
      <th>mdr_succ</th>
      <th>mdr_fail</th>
      <th>mdr_died</th>
      <th>mdr_lost</th>
      <th>xdr_coh</th>
      <th>xdr_succ</th>
      <th>xdr_fail</th>
      <th>xdr_died</th>
      <th>xdr_lost</th>
    </tr>
    <tr>
      <th>country</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>1994</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>1995</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>1996</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>1997</td>
      <td>100</td>
      <td>2001.00000</td>
      <td>786.000000</td>
      <td>108.000000</td>
      <td>33.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>1998</td>
      <td>100</td>
      <td>2913.00000</td>
      <td>772.000000</td>
      <td>199.000000</td>
      <td>48.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 71 columns</p>
</div>



### Next, you should familiarize yourself with the nature of the Dataset. This would give you an idea of what the dataset looks like


```python
dataset.shape
```




    (5118, 71)




```python
dataset.dtypes
```




    iso2            object
    iso3            object
    iso_numeric      int64
    g_whoregion     object
    year             int64
                    ...   
    xdr_coh        float64
    xdr_succ       float64
    xdr_fail       float64
    xdr_died       float64
    xdr_lost       float64
    Length: 71, dtype: object




```python
type(dataset)
```




    pandas.core.frame.DataFrame




```python
dataset.shape
```




    (5118, 71)




```python
dataset.size
```




    363378




```python
dataset.index
```




    Index(['Afghanistan', 'Afghanistan', 'Afghanistan', 'Afghanistan',
           'Afghanistan', 'Afghanistan', 'Afghanistan', 'Afghanistan',
           'Afghanistan', 'Afghanistan',
           ...
           'Zimbabwe', 'Zimbabwe', 'Zimbabwe', 'Zimbabwe', 'Zimbabwe', 'Zimbabwe',
           'Zimbabwe', 'Zimbabwe', 'Zimbabwe', 'Zimbabwe'],
          dtype='object', name='country', length=5118)




```python
dataset.columns
```




    Index(['iso2', 'iso3', 'iso_numeric', 'g_whoregion', 'year', 'rep_meth',
           'new_sp_coh', 'new_sp_cur', 'new_sp_cmplt', 'new_sp_died',
           'new_sp_fail', 'new_sp_def', 'c_new_sp_tsr', 'new_snep_coh',
           'new_snep_cmplt', 'new_snep_died', 'new_snep_fail', 'new_snep_def',
           'c_new_snep_tsr', 'ret_coh', 'ret_cur', 'ret_cmplt', 'ret_died',
           'ret_fail', 'ret_def', 'hiv_new_sp_coh', 'hiv_new_sp_cur',
           'hiv_new_sp_cmplt', 'hiv_new_sp_died', 'hiv_new_sp_fail',
           'hiv_new_sp_def', 'hiv_new_snep_coh', 'hiv_new_snep_cmplt',
           'hiv_new_snep_died', 'hiv_new_snep_fail', 'hiv_new_snep_def',
           'hiv_ret_coh', 'hiv_ret_cur', 'hiv_ret_cmplt', 'hiv_ret_died',
           'hiv_ret_fail', 'hiv_ret_def', 'rel_with_new_flg', 'newrel_coh',
           'newrel_succ', 'newrel_fail', 'newrel_died', 'newrel_lost', 'c_new_tsr',
           'ret_nrel_coh', 'ret_nrel_succ', 'ret_nrel_fail', 'ret_nrel_died',
           'ret_nrel_lost', 'c_ret_tsr', 'tbhiv_coh', 'tbhiv_succ', 'tbhiv_fail',
           'tbhiv_died', 'tbhiv_lost', 'c_tbhiv_tsr', 'mdr_coh', 'mdr_succ',
           'mdr_fail', 'mdr_died', 'mdr_lost', 'xdr_coh', 'xdr_succ', 'xdr_fail',
           'xdr_died', 'xdr_lost'],
          dtype='object')




```python
dataset.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>iso_numeric</th>
      <th>year</th>
      <th>rep_meth</th>
      <th>new_sp_coh</th>
      <th>new_sp_cur</th>
      <th>new_sp_cmplt</th>
      <th>new_sp_died</th>
      <th>new_sp_fail</th>
      <th>new_sp_def</th>
      <th>c_new_sp_tsr</th>
      <th>...</th>
      <th>mdr_coh</th>
      <th>mdr_succ</th>
      <th>mdr_fail</th>
      <th>mdr_died</th>
      <th>mdr_lost</th>
      <th>xdr_coh</th>
      <th>xdr_succ</th>
      <th>xdr_fail</th>
      <th>xdr_died</th>
      <th>xdr_lost</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>count</td>
      <td>5118.000000</td>
      <td>5118.000000</td>
      <td>5118.000000</td>
      <td>5118.00000</td>
      <td>5118.000000</td>
      <td>5118.000000</td>
      <td>5118.000000</td>
      <td>5118.000000</td>
      <td>5118.000000</td>
      <td>5118.000000</td>
      <td>...</td>
      <td>5118.000000</td>
      <td>5118.000000</td>
      <td>5118.000000</td>
      <td>5118.000000</td>
      <td>5118.000000</td>
      <td>5118.000000</td>
      <td>5118.000000</td>
      <td>5118.000000</td>
      <td>5118.000000</td>
      <td>5118.000000</td>
    </tr>
    <tr>
      <td>mean</td>
      <td>432.063111</td>
      <td>2005.565651</td>
      <td>100.528136</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>183.931226</td>
      <td>612.922218</td>
      <td>75.762475</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.204480</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>std</td>
      <td>253.529561</td>
      <td>6.926333</td>
      <td>0.825792</td>
      <td>35233.88547</td>
      <td>28455.963769</td>
      <td>2521.550115</td>
      <td>1235.695062</td>
      <td>609.162128</td>
      <td>1813.530176</td>
      <td>12.486306</td>
      <td>...</td>
      <td>1137.915599</td>
      <td>566.443670</td>
      <td>120.105034</td>
      <td>208.986493</td>
      <td>187.011733</td>
      <td>96.571655</td>
      <td>31.292655</td>
      <td>20.156968</td>
      <td>28.527600</td>
      <td>10.331911</td>
    </tr>
    <tr>
      <td>min</td>
      <td>4.000000</td>
      <td>1994.000000</td>
      <td>100.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>25%</td>
      <td>212.000000</td>
      <td>2000.000000</td>
      <td>100.000000</td>
      <td>689.00000</td>
      <td>395.500000</td>
      <td>81.000000</td>
      <td>38.000000</td>
      <td>9.000000</td>
      <td>49.000000</td>
      <td>75.762475</td>
      <td>...</td>
      <td>34.000000</td>
      <td>24.000000</td>
      <td>1.000000</td>
      <td>6.000000</td>
      <td>4.000000</td>
      <td>19.250000</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>50%</td>
      <td>430.000000</td>
      <td>2006.000000</td>
      <td>100.000000</td>
      <td>10751.50000</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>183.931226</td>
      <td>612.922218</td>
      <td>75.762475</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.204480</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>75%</td>
      <td>643.000000</td>
      <td>2012.000000</td>
      <td>101.000000</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>183.931226</td>
      <td>612.922218</td>
      <td>81.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.204480</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>max</td>
      <td>894.000000</td>
      <td>2017.000000</td>
      <td>102.000000</td>
      <td>642321.00000</td>
      <td>544731.000000</td>
      <td>64938.000000</td>
      <td>27005.000000</td>
      <td>12505.000000</td>
      <td>35469.000000</td>
      <td>100.000000</td>
      <td>...</td>
      <td>33197.000000</td>
      <td>15872.000000</td>
      <td>2916.000000</td>
      <td>6144.000000</td>
      <td>6324.000000</td>
      <td>2909.000000</td>
      <td>1094.000000</td>
      <td>633.000000</td>
      <td>1016.000000</td>
      <td>348.000000</td>
    </tr>
  </tbody>
</table>
<p>8 rows × 68 columns</p>
</div>



### Next, check the dataset for duplicated values and treat them accordingly if any


```python
dataset[dataset.duplicated()].sum()
```




    iso2           0.0
    iso3           0.0
    iso_numeric    0.0
    g_whoregion    0.0
    year           0.0
                  ... 
    xdr_coh        0.0
    xdr_succ       0.0
    xdr_fail       0.0
    xdr_died       0.0
    xdr_lost       0.0
    Length: 71, dtype: float64



### The Dataset contains no duplicate values as it's indicated  in the results above. That's a plus, so proceed to othet data Preparation steps

### The Dataset contains no null values because I'm working with the version of the file which ive cleaned and manipulate beforehand. When you get your file, it will require some data cleaning and formatting before it'll be ready for analysis and exploration


```python
dataset.isna().sum()
```




    iso2           0
    iso3           0
    iso_numeric    0
    g_whoregion    0
    year           0
                  ..
    xdr_coh        0
    xdr_succ       0
    xdr_fail       0
    xdr_died       0
    xdr_lost       0
    Length: 71, dtype: int64




```python
dataset.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Index: 5118 entries, Afghanistan to Zimbabwe
    Data columns (total 71 columns):
    iso2                  5118 non-null object
    iso3                  5118 non-null object
    iso_numeric           5118 non-null int64
    g_whoregion           5118 non-null object
    year                  5118 non-null int64
    rep_meth              5118 non-null int64
    new_sp_coh            5118 non-null float64
    new_sp_cur            5118 non-null float64
    new_sp_cmplt          5118 non-null float64
    new_sp_died           5118 non-null float64
    new_sp_fail           5118 non-null float64
    new_sp_def            5118 non-null float64
    c_new_sp_tsr          5118 non-null float64
    new_snep_coh          5118 non-null float64
    new_snep_cmplt        5118 non-null float64
    new_snep_died         5118 non-null float64
    new_snep_fail         5118 non-null float64
    new_snep_def          5118 non-null float64
    c_new_snep_tsr        5118 non-null float64
    ret_coh               5118 non-null float64
    ret_cur               5118 non-null float64
    ret_cmplt             5118 non-null float64
    ret_died              5118 non-null float64
    ret_fail              5118 non-null float64
    ret_def               5118 non-null float64
    hiv_new_sp_coh        5118 non-null float64
    hiv_new_sp_cur        5118 non-null float64
    hiv_new_sp_cmplt      5118 non-null float64
    hiv_new_sp_died       5118 non-null float64
    hiv_new_sp_fail       5118 non-null float64
    hiv_new_sp_def        5118 non-null float64
    hiv_new_snep_coh      5118 non-null float64
    hiv_new_snep_cmplt    5118 non-null float64
    hiv_new_snep_died     5118 non-null float64
    hiv_new_snep_fail     5118 non-null float64
    hiv_new_snep_def      5118 non-null float64
    hiv_ret_coh           5118 non-null float64
    hiv_ret_cur           5118 non-null float64
    hiv_ret_cmplt         5118 non-null float64
    hiv_ret_died          5118 non-null float64
    hiv_ret_fail          5118 non-null float64
    hiv_ret_def           5118 non-null float64
    rel_with_new_flg      5118 non-null float64
    newrel_coh            5118 non-null float64
    newrel_succ           5118 non-null float64
    newrel_fail           5118 non-null float64
    newrel_died           5118 non-null float64
    newrel_lost           5118 non-null float64
    c_new_tsr             5118 non-null float64
    ret_nrel_coh          5118 non-null float64
    ret_nrel_succ         5118 non-null float64
    ret_nrel_fail         5118 non-null float64
    ret_nrel_died         5118 non-null float64
    ret_nrel_lost         5118 non-null float64
    c_ret_tsr             5118 non-null float64
    tbhiv_coh             5118 non-null float64
    tbhiv_succ            5118 non-null float64
    tbhiv_fail            5118 non-null float64
    tbhiv_died            5118 non-null float64
    tbhiv_lost            5118 non-null float64
    c_tbhiv_tsr           5118 non-null float64
    mdr_coh               5118 non-null float64
    mdr_succ              5118 non-null float64
    mdr_fail              5118 non-null float64
    mdr_died              5118 non-null float64
    mdr_lost              5118 non-null float64
    xdr_coh               5118 non-null float64
    xdr_succ              5118 non-null float64
    xdr_fail              5118 non-null float64
    xdr_died              5118 non-null float64
    xdr_lost              5118 non-null float64
    dtypes: float64(65), int64(3), object(3)
    memory usage: 2.7+ MB


### Checking the various types of data types contained in the datset and summing it together. It's just part of understanding the data in question


```python
dataset.dtypes.value_counts()
```




    float64    65
    int64       3
    object      3
    dtype: int64



### The dataset is now ready for analysis and exploration to derive insights.

### The insights and visualization you derive from any Dataset depends on your goal. For the sake of practice and learning, most of what will be done here will be on random basis just to help you build your skills

### First,  you'll determine how many countries are represented in the dataset


```python
countries_present = dataset.index.unique()
countries_present1 = len(countries_present)
countries_present1
```




    218




```python
print("There are",countries_present1,"countries represented on this dataset")
```

    There are 218 countries represented on this dataset


### Next,  let's determine the number of regions represented in this dataset


```python
regions_present = dataset["g_whoregion"].unique()
regions_present1 = len(regions_present)
regions_present1
```




    6




```python
print("There are", regions_present1,"regions represented on this dataset")
```

    There are 6 regions represented on this dataset


### A visual plot of the regions in the dataset is good to plot at this stage. It's represented by a horizontal bar chart . Even if a pie chart is utilized, it'll still work perfectly.


```python
regs = dataset["g_whoregion"].groupby(dataset['g_whoregion'])
regs1 = regs.size()
regs11 = regs1.sort_values()
regs11.plot.barh()
plt.title("Regions Present", alpha = 0.85)
plt.ylabel("Regions", alpha = 0.7, fontstyle = 'italic')
```




    Text(0, 0.5, 'Regions')




![png](output_30_1.png)


### Next is to determine the unique number of years that was covered in the dataset


```python
years_covered = dataset.year.unique()
years_covered1 = len(years_covered)
years_covered1
```




    24




```python
print('The number of years covered in this dataset is',years_covered1,"years. It spans between", years_covered.min(),"to",years_covered.max())
```

    The number of years covered in this dataset is 24 years. It spans between 1994 to 2017


### Next, Let's extract the number of countries that's present in each region


```python
curled = dataset["rep_meth"].groupby([dataset["g_whoregion"],dataset.index])
curled1 = curled.size()
curled1
```




    g_whoregion  country                  
    AFR          Algeria                      24
                 Angola                       24
                 Benin                        24
                 Botswana                     24
                 Burkina Faso                 24
                                              ..
    WPR          Tonga                        24
                 Tuvalu                       24
                 Vanuatu                      24
                 Viet Nam                     24
                 Wallis and Futuna Islands    24
    Name: rep_meth, Length: 218, dtype: int64




```python
curled11 = curled1.unstack(0)
curled11
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>g_whoregion</th>
      <th>AFR</th>
      <th>AMR</th>
      <th>EMR</th>
      <th>EUR</th>
      <th>SEA</th>
      <th>WPR</th>
    </tr>
    <tr>
      <th>country</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Afghanistan</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>24.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>Albania</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>24.0</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>Algeria</td>
      <td>24.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>American Samoa</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>24.0</td>
    </tr>
    <tr>
      <td>Andorra</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>24.0</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <td>Wallis and Futuna Islands</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>24.0</td>
    </tr>
    <tr>
      <td>West Bank and Gaza Strip</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>24.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>Yemen</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>24.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>Zambia</td>
      <td>24.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>Zimbabwe</td>
      <td>24.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>218 rows × 6 columns</p>
</div>



### A dataframe containing the regions and the countries has been extracted. The next few steps will be to extract each region and its corresponding countries.

### Now let's extract the information which reveals the  number of countries in the AFR Region


```python
AFR_countries = curled11.AFR[curled11.AFR > 0]
AFR_countries1 = AFR_countries.count()
AFR_countries1
```




    47




```python
print("There are", AFR_countries1,"countries in \"AFR\" region")
```

    There are 47 countries in "AFR" region


### Next, Let's extract the information which reveals the number of countries in the AMR region


```python
AMR_countries = curled11.AMR[curled11.AMR > 0]
AMR_countries1 = AMR_countries.count()
AMR_countries1
```




    47




```python
print("There are",AMR_countries1,"countries in the \"AMR\" region")
```

    There are 47 countries in the "AMR" region


### Next, I'm going to extract the information that reveals the countries in the EMR Region


```python
EMR_countries = curled11.EMR[curled11.EMR > 0]
EMR_countries1 = EMR_countries.count()
EMR_countries1
```




    22




```python
print("There are",EMR_countries1,"countries in the \"EMR\" Region")
```

    There are 22 countries in the "EMR" Region


### Next, Let's extract the information which reveals the countries in the EUR Region


```python
EUR_countries = curled11.EUR[curled11.EUR > 0]
EUR_countries1 = EUR_countries.count()
EUR_countries1
```




    55




```python
print("There are",EUR_countries1,"countries in the \"EUR\" Region")
```

    There are 55 countries in the "EUR" Region


### Next, Let's extract the information that reveals the number of countries in the SEA Region


```python
SEA_countries = curled11.SEA[curled11.SEA > 0]
SEA_countries1 = SEA_countries.count()
SEA_countries1
```




    11




```python
print("There are",SEA_countries1,"countries in the \"SEA\" Region")
```

    There are 11 countries in the "SEA" Region


### Next, Let's extract the information that reveals the countries in the WPR Region


```python
WPR_countries = curled11.WPR[curled11.WPR > 0]
WPR_countries1 = WPR_countries.count()
WPR_countries1
```




    36




```python
print("There are",WPR_countries1,"countries in the \"WPR\" Region")
```

    There are 36 countries in the "WPR" Region



```python
dataset.tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>iso2</th>
      <th>iso3</th>
      <th>iso_numeric</th>
      <th>g_whoregion</th>
      <th>year</th>
      <th>rep_meth</th>
      <th>new_sp_coh</th>
      <th>new_sp_cur</th>
      <th>new_sp_cmplt</th>
      <th>new_sp_died</th>
      <th>...</th>
      <th>mdr_coh</th>
      <th>mdr_succ</th>
      <th>mdr_fail</th>
      <th>mdr_died</th>
      <th>mdr_lost</th>
      <th>xdr_coh</th>
      <th>xdr_succ</th>
      <th>xdr_fail</th>
      <th>xdr_died</th>
      <th>xdr_lost</th>
    </tr>
    <tr>
      <th>country</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Zimbabwe</td>
      <td>ZW</td>
      <td>ZWE</td>
      <td>716</td>
      <td>AFR</td>
      <td>2013</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>351.000000</td>
      <td>207.000000</td>
      <td>1.000000</td>
      <td>43.000000</td>
      <td>14.000000</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Zimbabwe</td>
      <td>ZW</td>
      <td>ZWE</td>
      <td>716</td>
      <td>AFR</td>
      <td>2014</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>381.000000</td>
      <td>193.000000</td>
      <td>6.000000</td>
      <td>66.000000</td>
      <td>21.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>Zimbabwe</td>
      <td>ZW</td>
      <td>ZWE</td>
      <td>716</td>
      <td>AFR</td>
      <td>2015</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>433.000000</td>
      <td>189.000000</td>
      <td>8.000000</td>
      <td>75.000000</td>
      <td>22.000000</td>
      <td>5.00000</td>
      <td>4.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>Zimbabwe</td>
      <td>ZW</td>
      <td>ZWE</td>
      <td>716</td>
      <td>AFR</td>
      <td>2016</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>488.000000</td>
      <td>276.000000</td>
      <td>0.000000</td>
      <td>149.000000</td>
      <td>44.000000</td>
      <td>5.00000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>2.000000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <td>Zimbabwe</td>
      <td>ZW</td>
      <td>ZWE</td>
      <td>716</td>
      <td>AFR</td>
      <td>2017</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 71 columns</p>
</div>



## Next, I'm going to determine the specific regions and the number of countries in that region that were attended to in each of the years contained in the dataset.

### I strongly feel plotting visualization for this part of the analysis is not so much appropriate. If you decide that doing so will make more meaning, feel free to unleash your imagination


```python
print('The number of years covered in this dataset is',years_covered1,"years. It spans between", years_covered.min(),"to",years_covered.max())
```

    The number of years covered in this dataset is 24 years. It spans between 1994 to 2017



```python
extract094 = dataset[dataset.year == 1994]
extract094
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>iso2</th>
      <th>iso3</th>
      <th>iso_numeric</th>
      <th>g_whoregion</th>
      <th>year</th>
      <th>rep_meth</th>
      <th>new_sp_coh</th>
      <th>new_sp_cur</th>
      <th>new_sp_cmplt</th>
      <th>new_sp_died</th>
      <th>...</th>
      <th>mdr_coh</th>
      <th>mdr_succ</th>
      <th>mdr_fail</th>
      <th>mdr_died</th>
      <th>mdr_lost</th>
      <th>xdr_coh</th>
      <th>xdr_succ</th>
      <th>xdr_fail</th>
      <th>xdr_died</th>
      <th>xdr_lost</th>
    </tr>
    <tr>
      <th>country</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>1994</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Albania</td>
      <td>AL</td>
      <td>ALB</td>
      <td>8</td>
      <td>EUR</td>
      <td>1994</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Algeria</td>
      <td>DZ</td>
      <td>DZA</td>
      <td>12</td>
      <td>AFR</td>
      <td>1994</td>
      <td>100</td>
      <td>7253.00000</td>
      <td>7887.186906</td>
      <td>5655.000000</td>
      <td>199.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>American Samoa</td>
      <td>AS</td>
      <td>ASM</td>
      <td>16</td>
      <td>WPR</td>
      <td>1994</td>
      <td>102</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Andorra</td>
      <td>AD</td>
      <td>AND</td>
      <td>20</td>
      <td>EUR</td>
      <td>1994</td>
      <td>102</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <td>Wallis and Futuna Islands</td>
      <td>WF</td>
      <td>WLF</td>
      <td>876</td>
      <td>WPR</td>
      <td>1994</td>
      <td>100</td>
      <td>5.00000</td>
      <td>0.000000</td>
      <td>4.000000</td>
      <td>1.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>West Bank and Gaza Strip</td>
      <td>PS</td>
      <td>PSE</td>
      <td>275</td>
      <td>EMR</td>
      <td>1994</td>
      <td>102</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Yemen</td>
      <td>YE</td>
      <td>YEM</td>
      <td>887</td>
      <td>EMR</td>
      <td>1994</td>
      <td>100</td>
      <td>3351.00000</td>
      <td>1035.000000</td>
      <td>291.000000</td>
      <td>21.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Zambia</td>
      <td>ZM</td>
      <td>ZMB</td>
      <td>894</td>
      <td>AFR</td>
      <td>1994</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Zimbabwe</td>
      <td>ZW</td>
      <td>ZWE</td>
      <td>716</td>
      <td>AFR</td>
      <td>1994</td>
      <td>100</td>
      <td>6724.00000</td>
      <td>1701.000000</td>
      <td>1772.000000</td>
      <td>645.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
  </tbody>
</table>
<p>211 rows × 71 columns</p>
</div>




```python
extract094.year.unique()
```




    array([1994], dtype=int64)




```python
count094 = extract094.rep_meth.groupby(extract094.index)
count94 = count094.count()
count94.head(20)
```




    country
    Afghanistan            1
    Albania                1
    Algeria                1
    American Samoa         1
    Andorra                1
    Angola                 1
    Anguilla               1
    Antigua and Barbuda    1
    Argentina              1
    Armenia                1
    Aruba                  1
    Australia              1
    Austria                1
    Azerbaijan             1
    Bahamas                1
    Bahrain                1
    Bangladesh             1
    Barbados               1
    Belarus                1
    Belgium                1
    Name: rep_meth, dtype: int64




```python
regions094 = extract094.rep_meth.groupby(extract094["g_whoregion"])
regions94 = regions094.size()
regions94
```




    g_whoregion
    AFR    46
    AMR    44
    EMR    22
    EUR    53
    SEA    10
    WPR    36
    Name: rep_meth, dtype: int64




```python
print("In the year",extract094.year.unique(),",",len(count94.index),"Countries were attended to and",len(regions94.index),"Regions were attended to respectively")
```

    In the year [1994] , 211 Countries were attended to and 6 Regions were attended to respectively



```python
extract095 = dataset[dataset.year == 1995]
extract095
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>iso2</th>
      <th>iso3</th>
      <th>iso_numeric</th>
      <th>g_whoregion</th>
      <th>year</th>
      <th>rep_meth</th>
      <th>new_sp_coh</th>
      <th>new_sp_cur</th>
      <th>new_sp_cmplt</th>
      <th>new_sp_died</th>
      <th>...</th>
      <th>mdr_coh</th>
      <th>mdr_succ</th>
      <th>mdr_fail</th>
      <th>mdr_died</th>
      <th>mdr_lost</th>
      <th>xdr_coh</th>
      <th>xdr_succ</th>
      <th>xdr_fail</th>
      <th>xdr_died</th>
      <th>xdr_lost</th>
    </tr>
    <tr>
      <th>country</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>1995</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Albania</td>
      <td>AL</td>
      <td>ALB</td>
      <td>8</td>
      <td>EUR</td>
      <td>1995</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Algeria</td>
      <td>DZ</td>
      <td>DZA</td>
      <td>12</td>
      <td>AFR</td>
      <td>1995</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>American Samoa</td>
      <td>AS</td>
      <td>ASM</td>
      <td>16</td>
      <td>WPR</td>
      <td>1995</td>
      <td>100</td>
      <td>4.00000</td>
      <td>4.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Andorra</td>
      <td>AD</td>
      <td>AND</td>
      <td>20</td>
      <td>EUR</td>
      <td>1995</td>
      <td>102</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <td>Wallis and Futuna Islands</td>
      <td>WF</td>
      <td>WLF</td>
      <td>876</td>
      <td>WPR</td>
      <td>1995</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>West Bank and Gaza Strip</td>
      <td>PS</td>
      <td>PSE</td>
      <td>275</td>
      <td>EMR</td>
      <td>1995</td>
      <td>100</td>
      <td>13.00000</td>
      <td>13.000000</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Yemen</td>
      <td>YE</td>
      <td>YEM</td>
      <td>887</td>
      <td>EMR</td>
      <td>1995</td>
      <td>100</td>
      <td>3681.00000</td>
      <td>1598.000000</td>
      <td>333.000000</td>
      <td>40.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Zambia</td>
      <td>ZM</td>
      <td>ZMB</td>
      <td>894</td>
      <td>AFR</td>
      <td>1995</td>
      <td>100</td>
      <td>5957.00000</td>
      <td>2815.000000</td>
      <td>1351.000000</td>
      <td>391.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Zimbabwe</td>
      <td>ZW</td>
      <td>ZWE</td>
      <td>716</td>
      <td>AFR</td>
      <td>1995</td>
      <td>100</td>
      <td>9702.00000</td>
      <td>3137.000000</td>
      <td>2032.000000</td>
      <td>983.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
  </tbody>
</table>
<p>211 rows × 71 columns</p>
</div>




```python
extract095.year.unique()
```




    array([1995], dtype=int64)




```python
count095 = extract095.rep_meth.groupby(extract095.index)
count95 = count095.count()
count95
```




    country
    Afghanistan                  1
    Albania                      1
    Algeria                      1
    American Samoa               1
    Andorra                      1
                                ..
    Wallis and Futuna Islands    1
    West Bank and Gaza Strip     1
    Yemen                        1
    Zambia                       1
    Zimbabwe                     1
    Name: rep_meth, Length: 211, dtype: int64




```python
regions095 = extract095.rep_meth.groupby(extract095["g_whoregion"])
regions95 = regions095.size()
regions95
```




    g_whoregion
    AFR    46
    AMR    44
    EMR    22
    EUR    53
    SEA    10
    WPR    36
    Name: rep_meth, dtype: int64




```python
print("In the year",extract095.year.unique(),",",len(count95.index),"countries were attended to and",len(regions95.index),"Regions were attended to respectively")
```

    In the year [1995] , 211 countries were attended to and 6 Regions were attended to respectively



```python
extract096 = dataset[dataset.year == 1996]
extract096
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>iso2</th>
      <th>iso3</th>
      <th>iso_numeric</th>
      <th>g_whoregion</th>
      <th>year</th>
      <th>rep_meth</th>
      <th>new_sp_coh</th>
      <th>new_sp_cur</th>
      <th>new_sp_cmplt</th>
      <th>new_sp_died</th>
      <th>...</th>
      <th>mdr_coh</th>
      <th>mdr_succ</th>
      <th>mdr_fail</th>
      <th>mdr_died</th>
      <th>mdr_lost</th>
      <th>xdr_coh</th>
      <th>xdr_succ</th>
      <th>xdr_fail</th>
      <th>xdr_died</th>
      <th>xdr_lost</th>
    </tr>
    <tr>
      <th>country</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>1996</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Albania</td>
      <td>AL</td>
      <td>ALB</td>
      <td>8</td>
      <td>EUR</td>
      <td>1996</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Algeria</td>
      <td>DZ</td>
      <td>DZA</td>
      <td>12</td>
      <td>AFR</td>
      <td>1996</td>
      <td>100</td>
      <td>6860.00000</td>
      <td>5630.000000</td>
      <td>241.000000</td>
      <td>191.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>American Samoa</td>
      <td>AS</td>
      <td>ASM</td>
      <td>16</td>
      <td>WPR</td>
      <td>1996</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Andorra</td>
      <td>AD</td>
      <td>AND</td>
      <td>20</td>
      <td>EUR</td>
      <td>1996</td>
      <td>102</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <td>Wallis and Futuna Islands</td>
      <td>WF</td>
      <td>WLF</td>
      <td>876</td>
      <td>WPR</td>
      <td>1996</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>West Bank and Gaza Strip</td>
      <td>PS</td>
      <td>PSE</td>
      <td>275</td>
      <td>EMR</td>
      <td>1996</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Yemen</td>
      <td>YE</td>
      <td>YEM</td>
      <td>887</td>
      <td>EMR</td>
      <td>1996</td>
      <td>100</td>
      <td>4221.00000</td>
      <td>1936.000000</td>
      <td>253.000000</td>
      <td>54.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Zambia</td>
      <td>ZM</td>
      <td>ZMB</td>
      <td>894</td>
      <td>AFR</td>
      <td>1996</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Zimbabwe</td>
      <td>ZW</td>
      <td>ZWE</td>
      <td>716</td>
      <td>AFR</td>
      <td>1996</td>
      <td>100</td>
      <td>11965.00000</td>
      <td>3836.000000</td>
      <td>0.000000</td>
      <td>947.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
  </tbody>
</table>
<p>211 rows × 71 columns</p>
</div>




```python
extract096.year.unique()
```




    array([1996], dtype=int64)




```python
count096 = extract096.rep_meth.groupby(extract096.index)
count96 = count096.size()
count96
```




    country
    Afghanistan                  1
    Albania                      1
    Algeria                      1
    American Samoa               1
    Andorra                      1
                                ..
    Wallis and Futuna Islands    1
    West Bank and Gaza Strip     1
    Yemen                        1
    Zambia                       1
    Zimbabwe                     1
    Name: rep_meth, Length: 211, dtype: int64




```python
regions096 = extract096.rep_meth.groupby(extract096["g_whoregion"])
regions96 = regions096.size()
regions96
```




    g_whoregion
    AFR    46
    AMR    44
    EMR    22
    EUR    53
    SEA    10
    WPR    36
    Name: rep_meth, dtype: int64




```python
print("In the year",extract096.year.unique(),",",len(count96.index),"Countries were attended to and",len(regions96.index),"were attended to respectively")
```

    In the year [1996] , 211 Countries were attended to and 6 were attended to respectively



```python
extract097 = dataset[dataset.year == 1997]
extract097
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>iso2</th>
      <th>iso3</th>
      <th>iso_numeric</th>
      <th>g_whoregion</th>
      <th>year</th>
      <th>rep_meth</th>
      <th>new_sp_coh</th>
      <th>new_sp_cur</th>
      <th>new_sp_cmplt</th>
      <th>new_sp_died</th>
      <th>...</th>
      <th>mdr_coh</th>
      <th>mdr_succ</th>
      <th>mdr_fail</th>
      <th>mdr_died</th>
      <th>mdr_lost</th>
      <th>xdr_coh</th>
      <th>xdr_succ</th>
      <th>xdr_fail</th>
      <th>xdr_died</th>
      <th>xdr_lost</th>
    </tr>
    <tr>
      <th>country</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>1997</td>
      <td>100</td>
      <td>2001.00000</td>
      <td>786.000000</td>
      <td>108.000000</td>
      <td>33.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Albania</td>
      <td>AL</td>
      <td>ALB</td>
      <td>8</td>
      <td>EUR</td>
      <td>1997</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Algeria</td>
      <td>DZ</td>
      <td>DZA</td>
      <td>12</td>
      <td>AFR</td>
      <td>1997</td>
      <td>100</td>
      <td>6860.00000</td>
      <td>5630.000000</td>
      <td>241.000000</td>
      <td>191.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>American Samoa</td>
      <td>AS</td>
      <td>ASM</td>
      <td>16</td>
      <td>WPR</td>
      <td>1997</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Andorra</td>
      <td>AD</td>
      <td>AND</td>
      <td>20</td>
      <td>EUR</td>
      <td>1997</td>
      <td>102</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <td>Wallis and Futuna Islands</td>
      <td>WF</td>
      <td>WLF</td>
      <td>876</td>
      <td>WPR</td>
      <td>1997</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>West Bank and Gaza Strip</td>
      <td>PS</td>
      <td>PSE</td>
      <td>275</td>
      <td>EMR</td>
      <td>1997</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Yemen</td>
      <td>YE</td>
      <td>YEM</td>
      <td>887</td>
      <td>EMR</td>
      <td>1997</td>
      <td>100</td>
      <td>4365.00000</td>
      <td>2608.000000</td>
      <td>439.000000</td>
      <td>103.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Zambia</td>
      <td>ZM</td>
      <td>ZMB</td>
      <td>894</td>
      <td>AFR</td>
      <td>1997</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Zimbabwe</td>
      <td>ZW</td>
      <td>ZWE</td>
      <td>716</td>
      <td>AFR</td>
      <td>1997</td>
      <td>100</td>
      <td>12410.00000</td>
      <td>6361.000000</td>
      <td>2175.000000</td>
      <td>1260.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
  </tbody>
</table>
<p>211 rows × 71 columns</p>
</div>




```python
extract097.year.unique()
```




    array([1997], dtype=int64)




```python
count097 = extract097.rep_meth.groupby(extract097.index)
count97 = count097.size()
count97
```




    country
    Afghanistan                  1
    Albania                      1
    Algeria                      1
    American Samoa               1
    Andorra                      1
                                ..
    Wallis and Futuna Islands    1
    West Bank and Gaza Strip     1
    Yemen                        1
    Zambia                       1
    Zimbabwe                     1
    Name: rep_meth, Length: 211, dtype: int64




```python
regions097 = extract097.rep_meth.groupby(extract097["g_whoregion"])
regions97 = regions097.size()
regions97
```




    g_whoregion
    AFR    46
    AMR    44
    EMR    22
    EUR    53
    SEA    10
    WPR    36
    Name: rep_meth, dtype: int64




```python
print("In the year",extract097.year.unique(),",",len(count97.index),"Countries were attended to and",len(regions97.index),"Regions were attended to respectively")
```

    In the year [1997] , 211 Countries were attended to and 6 Regions were attended to respectively



```python
extract098 = dataset[dataset.year == 1998]
extract098
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>iso2</th>
      <th>iso3</th>
      <th>iso_numeric</th>
      <th>g_whoregion</th>
      <th>year</th>
      <th>rep_meth</th>
      <th>new_sp_coh</th>
      <th>new_sp_cur</th>
      <th>new_sp_cmplt</th>
      <th>new_sp_died</th>
      <th>...</th>
      <th>mdr_coh</th>
      <th>mdr_succ</th>
      <th>mdr_fail</th>
      <th>mdr_died</th>
      <th>mdr_lost</th>
      <th>xdr_coh</th>
      <th>xdr_succ</th>
      <th>xdr_fail</th>
      <th>xdr_died</th>
      <th>xdr_lost</th>
    </tr>
    <tr>
      <th>country</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>1998</td>
      <td>100</td>
      <td>2913.00000</td>
      <td>772.000000</td>
      <td>199.000000</td>
      <td>48.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Albania</td>
      <td>AL</td>
      <td>ALB</td>
      <td>8</td>
      <td>EUR</td>
      <td>1998</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Algeria</td>
      <td>DZ</td>
      <td>DZA</td>
      <td>12</td>
      <td>AFR</td>
      <td>1998</td>
      <td>100</td>
      <td>2490.00000</td>
      <td>1741.000000</td>
      <td>964.721656</td>
      <td>80.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>American Samoa</td>
      <td>AS</td>
      <td>ASM</td>
      <td>16</td>
      <td>WPR</td>
      <td>1998</td>
      <td>100</td>
      <td>4.00000</td>
      <td>2.000000</td>
      <td>964.721656</td>
      <td>0.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Andorra</td>
      <td>AD</td>
      <td>AND</td>
      <td>20</td>
      <td>EUR</td>
      <td>1998</td>
      <td>100</td>
      <td>2.00000</td>
      <td>0.000000</td>
      <td>2.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <td>Wallis and Futuna Islands</td>
      <td>WF</td>
      <td>WLF</td>
      <td>876</td>
      <td>WPR</td>
      <td>1998</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>West Bank and Gaza Strip</td>
      <td>PS</td>
      <td>PSE</td>
      <td>275</td>
      <td>EMR</td>
      <td>1998</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Yemen</td>
      <td>YE</td>
      <td>YEM</td>
      <td>887</td>
      <td>EMR</td>
      <td>1998</td>
      <td>100</td>
      <td>4983.00000</td>
      <td>2889.000000</td>
      <td>465.000000</td>
      <td>127.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Zambia</td>
      <td>ZM</td>
      <td>ZMB</td>
      <td>894</td>
      <td>AFR</td>
      <td>1998</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Zimbabwe</td>
      <td>ZW</td>
      <td>ZWE</td>
      <td>716</td>
      <td>AFR</td>
      <td>1998</td>
      <td>100</td>
      <td>12748.00000</td>
      <td>6420.000000</td>
      <td>2445.000000</td>
      <td>1272.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
  </tbody>
</table>
<p>211 rows × 71 columns</p>
</div>




```python
extract098.year.unique()
```




    array([1998], dtype=int64)




```python
count098 = extract098.rep_meth.groupby(extract098.index)
count98 = count098.size()
count98
```




    country
    Afghanistan                  1
    Albania                      1
    Algeria                      1
    American Samoa               1
    Andorra                      1
                                ..
    Wallis and Futuna Islands    1
    West Bank and Gaza Strip     1
    Yemen                        1
    Zambia                       1
    Zimbabwe                     1
    Name: rep_meth, Length: 211, dtype: int64




```python
regions098 = extract098.rep_meth.groupby(extract098["g_whoregion"])
regions98 = regions098.size()
regions98
```




    g_whoregion
    AFR    46
    AMR    44
    EMR    22
    EUR    53
    SEA    10
    WPR    36
    Name: rep_meth, dtype: int64




```python
print("In the year",extract098.year.unique(),",",len(count98.index),"Countries were attended to and",len(regions98.index),"were attended to respectively")
```

    In the year [1998] , 211 Countries were attended to and 6 were attended to respectively



```python
extract099 = dataset[dataset.year == 1999]
extract099
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>iso2</th>
      <th>iso3</th>
      <th>iso_numeric</th>
      <th>g_whoregion</th>
      <th>year</th>
      <th>rep_meth</th>
      <th>new_sp_coh</th>
      <th>new_sp_cur</th>
      <th>new_sp_cmplt</th>
      <th>new_sp_died</th>
      <th>...</th>
      <th>mdr_coh</th>
      <th>mdr_succ</th>
      <th>mdr_fail</th>
      <th>mdr_died</th>
      <th>mdr_lost</th>
      <th>xdr_coh</th>
      <th>xdr_succ</th>
      <th>xdr_fail</th>
      <th>xdr_died</th>
      <th>xdr_lost</th>
    </tr>
    <tr>
      <th>country</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>1999</td>
      <td>100</td>
      <td>2039.00000</td>
      <td>1571.000000</td>
      <td>189.000000</td>
      <td>83.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Albania</td>
      <td>AL</td>
      <td>ALB</td>
      <td>8</td>
      <td>EUR</td>
      <td>1999</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Algeria</td>
      <td>DZ</td>
      <td>DZA</td>
      <td>12</td>
      <td>AFR</td>
      <td>1999</td>
      <td>100</td>
      <td>7622.00000</td>
      <td>6621.000000</td>
      <td>964.721656</td>
      <td>191.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>American Samoa</td>
      <td>AS</td>
      <td>ASM</td>
      <td>16</td>
      <td>WPR</td>
      <td>1999</td>
      <td>100</td>
      <td>3.00000</td>
      <td>3.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Andorra</td>
      <td>AD</td>
      <td>AND</td>
      <td>20</td>
      <td>EUR</td>
      <td>1999</td>
      <td>100</td>
      <td>3.00000</td>
      <td>7887.186906</td>
      <td>2.000000</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <td>Wallis and Futuna Islands</td>
      <td>WF</td>
      <td>WLF</td>
      <td>876</td>
      <td>WPR</td>
      <td>1999</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>West Bank and Gaza Strip</td>
      <td>PS</td>
      <td>PSE</td>
      <td>275</td>
      <td>EMR</td>
      <td>1999</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Yemen</td>
      <td>YE</td>
      <td>YEM</td>
      <td>887</td>
      <td>EMR</td>
      <td>1999</td>
      <td>100</td>
      <td>5463.00000</td>
      <td>3482.000000</td>
      <td>561.000000</td>
      <td>154.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Zambia</td>
      <td>ZM</td>
      <td>ZMB</td>
      <td>894</td>
      <td>AFR</td>
      <td>1999</td>
      <td>100</td>
      <td>11645.00000</td>
      <td>5808.000000</td>
      <td>2238.000000</td>
      <td>850.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Zimbabwe</td>
      <td>ZW</td>
      <td>ZWE</td>
      <td>716</td>
      <td>AFR</td>
      <td>1999</td>
      <td>100</td>
      <td>12791.00000</td>
      <td>7535.000000</td>
      <td>1749.000000</td>
      <td>1281.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
  </tbody>
</table>
<p>211 rows × 71 columns</p>
</div>




```python
extract099.year.unique()
```




    array([1999], dtype=int64)




```python
count099 = extract099.rep_meth.groupby(extract099.index)
count99 = count099.size()
count99
```




    country
    Afghanistan                  1
    Albania                      1
    Algeria                      1
    American Samoa               1
    Andorra                      1
                                ..
    Wallis and Futuna Islands    1
    West Bank and Gaza Strip     1
    Yemen                        1
    Zambia                       1
    Zimbabwe                     1
    Name: rep_meth, Length: 211, dtype: int64




```python
regions099 = extract099.rep_meth.groupby(extract099["g_whoregion"])
regions99 = regions099.size()
regions99
```




    g_whoregion
    AFR    46
    AMR    44
    EMR    22
    EUR    53
    SEA    10
    WPR    36
    Name: rep_meth, dtype: int64




```python
print("In the year",extract099.year.unique(),",",len(count99.index),"Countries were attended to and",len(regions99.index),"Regions were attended to respectively")
```

    In the year [1999] , 211 Countries were attended to and 6 Regions were attended to respectively



```python
extract000 = dataset[dataset.year == 2000]
extract000
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>iso2</th>
      <th>iso3</th>
      <th>iso_numeric</th>
      <th>g_whoregion</th>
      <th>year</th>
      <th>rep_meth</th>
      <th>new_sp_coh</th>
      <th>new_sp_cur</th>
      <th>new_sp_cmplt</th>
      <th>new_sp_died</th>
      <th>...</th>
      <th>mdr_coh</th>
      <th>mdr_succ</th>
      <th>mdr_fail</th>
      <th>mdr_died</th>
      <th>mdr_lost</th>
      <th>xdr_coh</th>
      <th>xdr_succ</th>
      <th>xdr_fail</th>
      <th>xdr_died</th>
      <th>xdr_lost</th>
    </tr>
    <tr>
      <th>country</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>2000</td>
      <td>100</td>
      <td>3136.00000</td>
      <td>2396.000000</td>
      <td>283.000000</td>
      <td>107.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Albania</td>
      <td>AL</td>
      <td>ALB</td>
      <td>8</td>
      <td>EUR</td>
      <td>2000</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Algeria</td>
      <td>DZ</td>
      <td>DZA</td>
      <td>12</td>
      <td>AFR</td>
      <td>2000</td>
      <td>100</td>
      <td>8328.00000</td>
      <td>6690.000000</td>
      <td>583.000000</td>
      <td>56.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>American Samoa</td>
      <td>AS</td>
      <td>ASM</td>
      <td>16</td>
      <td>WPR</td>
      <td>2000</td>
      <td>100</td>
      <td>2.00000</td>
      <td>0.000000</td>
      <td>2.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Andorra</td>
      <td>AD</td>
      <td>AND</td>
      <td>20</td>
      <td>EUR</td>
      <td>2000</td>
      <td>100</td>
      <td>2.00000</td>
      <td>7887.186906</td>
      <td>1.000000</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <td>Wallis and Futuna Islands</td>
      <td>WF</td>
      <td>WLF</td>
      <td>876</td>
      <td>WPR</td>
      <td>2000</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>West Bank and Gaza Strip</td>
      <td>PS</td>
      <td>PSE</td>
      <td>275</td>
      <td>EMR</td>
      <td>2000</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Yemen</td>
      <td>YE</td>
      <td>YEM</td>
      <td>887</td>
      <td>EMR</td>
      <td>2000</td>
      <td>100</td>
      <td>5565.00000</td>
      <td>3273.000000</td>
      <td>707.000000</td>
      <td>191.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Zambia</td>
      <td>ZM</td>
      <td>ZMB</td>
      <td>894</td>
      <td>AFR</td>
      <td>2000</td>
      <td>100</td>
      <td>7014.00000</td>
      <td>3348.000000</td>
      <td>1358.000000</td>
      <td>478.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Zimbabwe</td>
      <td>ZW</td>
      <td>ZWE</td>
      <td>716</td>
      <td>AFR</td>
      <td>2000</td>
      <td>100</td>
      <td>14392.00000</td>
      <td>8820.000000</td>
      <td>1092.000000</td>
      <td>1656.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
  </tbody>
</table>
<p>211 rows × 71 columns</p>
</div>




```python
extract000.year.unique()
```




    array([2000], dtype=int64)




```python
count000 = extract000.rep_meth.groupby(extract000.index)
count00 = count000.size()
count00
```




    country
    Afghanistan                  1
    Albania                      1
    Algeria                      1
    American Samoa               1
    Andorra                      1
                                ..
    Wallis and Futuna Islands    1
    West Bank and Gaza Strip     1
    Yemen                        1
    Zambia                       1
    Zimbabwe                     1
    Name: rep_meth, Length: 211, dtype: int64




```python
regions000 = extract000.rep_meth.groupby(extract000["g_whoregion"])
regions00 = regions000.size()
regions00
```




    g_whoregion
    AFR    46
    AMR    44
    EMR    22
    EUR    53
    SEA    10
    WPR    36
    Name: rep_meth, dtype: int64




```python
print("In the year",extract000.year.unique(),",",len(count00.index),"Countries were attended to and",len(regions00.index),"Regions were attended to respectively")
```

    In the year [2000] , 211 Countries were attended to and 6 Regions were attended to respectively



```python
extract001 = dataset[dataset["year"] == 2001]
extract001
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>iso2</th>
      <th>iso3</th>
      <th>iso_numeric</th>
      <th>g_whoregion</th>
      <th>year</th>
      <th>rep_meth</th>
      <th>new_sp_coh</th>
      <th>new_sp_cur</th>
      <th>new_sp_cmplt</th>
      <th>new_sp_died</th>
      <th>...</th>
      <th>mdr_coh</th>
      <th>mdr_succ</th>
      <th>mdr_fail</th>
      <th>mdr_died</th>
      <th>mdr_lost</th>
      <th>xdr_coh</th>
      <th>xdr_succ</th>
      <th>xdr_fail</th>
      <th>xdr_died</th>
      <th>xdr_lost</th>
    </tr>
    <tr>
      <th>country</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>2001</td>
      <td>100</td>
      <td>6292.00000</td>
      <td>3305.000000</td>
      <td>2004.000000</td>
      <td>238.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Albania</td>
      <td>AL</td>
      <td>ALB</td>
      <td>8</td>
      <td>EUR</td>
      <td>2001</td>
      <td>100</td>
      <td>171.00000</td>
      <td>76.000000</td>
      <td>80.000000</td>
      <td>2.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Algeria</td>
      <td>DZ</td>
      <td>DZA</td>
      <td>12</td>
      <td>AFR</td>
      <td>2001</td>
      <td>100</td>
      <td>8361.00000</td>
      <td>4561.000000</td>
      <td>2462.000000</td>
      <td>195.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>American Samoa</td>
      <td>AS</td>
      <td>ASM</td>
      <td>16</td>
      <td>WPR</td>
      <td>2001</td>
      <td>100</td>
      <td>2.00000</td>
      <td>7887.186906</td>
      <td>2.000000</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Andorra</td>
      <td>AD</td>
      <td>AND</td>
      <td>20</td>
      <td>EUR</td>
      <td>2001</td>
      <td>100</td>
      <td>1.00000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <td>Wallis and Futuna Islands</td>
      <td>WF</td>
      <td>WLF</td>
      <td>876</td>
      <td>WPR</td>
      <td>2001</td>
      <td>100</td>
      <td>1.00000</td>
      <td>1.000000</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>West Bank and Gaza Strip</td>
      <td>PS</td>
      <td>PSE</td>
      <td>275</td>
      <td>EMR</td>
      <td>2001</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Yemen</td>
      <td>YE</td>
      <td>YEM</td>
      <td>887</td>
      <td>EMR</td>
      <td>2001</td>
      <td>100</td>
      <td>4968.00000</td>
      <td>3206.000000</td>
      <td>594.000000</td>
      <td>157.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Zambia</td>
      <td>ZM</td>
      <td>ZMB</td>
      <td>894</td>
      <td>AFR</td>
      <td>2001</td>
      <td>100</td>
      <td>13024.00000</td>
      <td>7246.000000</td>
      <td>2429.000000</td>
      <td>1450.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Zimbabwe</td>
      <td>ZW</td>
      <td>ZWE</td>
      <td>716</td>
      <td>AFR</td>
      <td>2001</td>
      <td>100</td>
      <td>16569.00000</td>
      <td>10521.000000</td>
      <td>1176.000000</td>
      <td>1972.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
  </tbody>
</table>
<p>211 rows × 71 columns</p>
</div>




```python
extract001.year.unique()
```




    array([2001], dtype=int64)




```python
count001 = extract001.rep_meth.groupby(extract001.index)
count01 = count001.size()
count01
```




    country
    Afghanistan                  1
    Albania                      1
    Algeria                      1
    American Samoa               1
    Andorra                      1
                                ..
    Wallis and Futuna Islands    1
    West Bank and Gaza Strip     1
    Yemen                        1
    Zambia                       1
    Zimbabwe                     1
    Name: rep_meth, Length: 211, dtype: int64




```python
regions001 = extract001.rep_meth.groupby(extract001["g_whoregion"])
regions01 = regions001.size()
regions01
```




    g_whoregion
    AFR    46
    AMR    44
    EMR    22
    EUR    53
    SEA    10
    WPR    36
    Name: rep_meth, dtype: int64




```python
print("In the year",extract001.year.unique(),",",len(count01.index),"Countries were attended to and",len(regions01.index),"were attended to respectively")
```

    In the year [2001] , 211 Countries were attended to and 6 were attended to respectively



```python
extract002 = dataset[dataset.year == 2002]
extract002
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>iso2</th>
      <th>iso3</th>
      <th>iso_numeric</th>
      <th>g_whoregion</th>
      <th>year</th>
      <th>rep_meth</th>
      <th>new_sp_coh</th>
      <th>new_sp_cur</th>
      <th>new_sp_cmplt</th>
      <th>new_sp_died</th>
      <th>...</th>
      <th>mdr_coh</th>
      <th>mdr_succ</th>
      <th>mdr_fail</th>
      <th>mdr_died</th>
      <th>mdr_lost</th>
      <th>xdr_coh</th>
      <th>xdr_succ</th>
      <th>xdr_fail</th>
      <th>xdr_died</th>
      <th>xdr_lost</th>
    </tr>
    <tr>
      <th>country</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>2002</td>
      <td>100</td>
      <td>7780.0</td>
      <td>4668.000000</td>
      <td>2090.000000</td>
      <td>308.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Albania</td>
      <td>AL</td>
      <td>ALB</td>
      <td>8</td>
      <td>EUR</td>
      <td>2002</td>
      <td>100</td>
      <td>225.0</td>
      <td>98.000000</td>
      <td>91.000000</td>
      <td>3.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Algeria</td>
      <td>DZ</td>
      <td>DZA</td>
      <td>12</td>
      <td>AFR</td>
      <td>2002</td>
      <td>100</td>
      <td>9200.0</td>
      <td>6631.000000</td>
      <td>1560.000000</td>
      <td>177.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>American Samoa</td>
      <td>AS</td>
      <td>ASM</td>
      <td>16</td>
      <td>WPR</td>
      <td>2002</td>
      <td>100</td>
      <td>1.0</td>
      <td>7887.186906</td>
      <td>1.000000</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Andorra</td>
      <td>AD</td>
      <td>AND</td>
      <td>20</td>
      <td>EUR</td>
      <td>2002</td>
      <td>100</td>
      <td>3.0</td>
      <td>3.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <td>Wallis and Futuna Islands</td>
      <td>WF</td>
      <td>WLF</td>
      <td>876</td>
      <td>WPR</td>
      <td>2002</td>
      <td>100</td>
      <td>5.0</td>
      <td>5.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>West Bank and Gaza Strip</td>
      <td>PS</td>
      <td>PSE</td>
      <td>275</td>
      <td>EMR</td>
      <td>2002</td>
      <td>100</td>
      <td>10.0</td>
      <td>10.000000</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Yemen</td>
      <td>YE</td>
      <td>YEM</td>
      <td>887</td>
      <td>EMR</td>
      <td>2002</td>
      <td>100</td>
      <td>4204.0</td>
      <td>2864.000000</td>
      <td>508.000000</td>
      <td>144.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Zambia</td>
      <td>ZM</td>
      <td>ZMB</td>
      <td>894</td>
      <td>AFR</td>
      <td>2002</td>
      <td>100</td>
      <td>16351.0</td>
      <td>10410.000000</td>
      <td>2658.000000</td>
      <td>1811.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Zimbabwe</td>
      <td>ZW</td>
      <td>ZWE</td>
      <td>716</td>
      <td>AFR</td>
      <td>2002</td>
      <td>100</td>
      <td>15941.0</td>
      <td>9833.000000</td>
      <td>898.000000</td>
      <td>1801.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
  </tbody>
</table>
<p>212 rows × 71 columns</p>
</div>




```python
extract002.year.unique()
```




    array([2002], dtype=int64)




```python
count002 = extract002.rep_meth.groupby(extract002.index)
count02 = count002.size()
count02
```




    country
    Afghanistan                  1
    Albania                      1
    Algeria                      1
    American Samoa               1
    Andorra                      1
                                ..
    Wallis and Futuna Islands    1
    West Bank and Gaza Strip     1
    Yemen                        1
    Zambia                       1
    Zimbabwe                     1
    Name: rep_meth, Length: 212, dtype: int64




```python
regions002 = extract002.rep_meth.groupby(extract002["g_whoregion"])
regions02 = regions002.size()
regions02
```




    g_whoregion
    AFR    46
    AMR    44
    EMR    22
    EUR    53
    SEA    11
    WPR    36
    Name: rep_meth, dtype: int64




```python
print("In the year",extract002.year.unique(),",",len(count02.index),"Countries were attended to and",len(regions02.index),"were attended to respectively")
```

    In the year [2002] , 212 Countries were attended to and 6 were attended to respectively



```python
extract003 = dataset[dataset.year == 2003]
extract003
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>iso2</th>
      <th>iso3</th>
      <th>iso_numeric</th>
      <th>g_whoregion</th>
      <th>year</th>
      <th>rep_meth</th>
      <th>new_sp_coh</th>
      <th>new_sp_cur</th>
      <th>new_sp_cmplt</th>
      <th>new_sp_died</th>
      <th>...</th>
      <th>mdr_coh</th>
      <th>mdr_succ</th>
      <th>mdr_fail</th>
      <th>mdr_died</th>
      <th>mdr_lost</th>
      <th>xdr_coh</th>
      <th>xdr_succ</th>
      <th>xdr_fail</th>
      <th>xdr_died</th>
      <th>xdr_lost</th>
    </tr>
    <tr>
      <th>country</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>2003</td>
      <td>100</td>
      <td>6793.00000</td>
      <td>5505.000000</td>
      <td>340.000000</td>
      <td>229.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Albania</td>
      <td>AL</td>
      <td>ALB</td>
      <td>8</td>
      <td>EUR</td>
      <td>2003</td>
      <td>100</td>
      <td>212.00000</td>
      <td>104.000000</td>
      <td>82.000000</td>
      <td>7.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Algeria</td>
      <td>DZ</td>
      <td>DZA</td>
      <td>12</td>
      <td>AFR</td>
      <td>2003</td>
      <td>100</td>
      <td>8521.00000</td>
      <td>6548.000000</td>
      <td>1079.000000</td>
      <td>176.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>American Samoa</td>
      <td>AS</td>
      <td>ASM</td>
      <td>16</td>
      <td>WPR</td>
      <td>2003</td>
      <td>100</td>
      <td>2.00000</td>
      <td>2.000000</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Andorra</td>
      <td>AD</td>
      <td>AND</td>
      <td>20</td>
      <td>EUR</td>
      <td>2003</td>
      <td>100</td>
      <td>6.00000</td>
      <td>6.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <td>Wallis and Futuna Islands</td>
      <td>WF</td>
      <td>WLF</td>
      <td>876</td>
      <td>WPR</td>
      <td>2003</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>West Bank and Gaza Strip</td>
      <td>PS</td>
      <td>PSE</td>
      <td>275</td>
      <td>EMR</td>
      <td>2003</td>
      <td>100</td>
      <td>15.00000</td>
      <td>10.000000</td>
      <td>2.000000</td>
      <td>2.000000</td>
      <td>...</td>
      <td>2.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>2.000000</td>
      <td>0.000000</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Yemen</td>
      <td>YE</td>
      <td>YEM</td>
      <td>887</td>
      <td>EMR</td>
      <td>2003</td>
      <td>100</td>
      <td>3793.00000</td>
      <td>2624.000000</td>
      <td>474.000000</td>
      <td>127.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Zambia</td>
      <td>ZM</td>
      <td>ZMB</td>
      <td>894</td>
      <td>AFR</td>
      <td>2003</td>
      <td>100</td>
      <td>18934.00000</td>
      <td>12603.000000</td>
      <td>1599.000000</td>
      <td>1492.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Zimbabwe</td>
      <td>ZW</td>
      <td>ZWE</td>
      <td>716</td>
      <td>AFR</td>
      <td>2003</td>
      <td>100</td>
      <td>14488.00000</td>
      <td>8892.000000</td>
      <td>633.000000</td>
      <td>1740.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
  </tbody>
</table>
<p>212 rows × 71 columns</p>
</div>




```python
extract003.year.unique()
```




    array([2003], dtype=int64)




```python
count003 = extract003.rep_meth.groupby(extract003.index)
count03 = count003.size()
count03
```




    country
    Afghanistan                  1
    Albania                      1
    Algeria                      1
    American Samoa               1
    Andorra                      1
                                ..
    Wallis and Futuna Islands    1
    West Bank and Gaza Strip     1
    Yemen                        1
    Zambia                       1
    Zimbabwe                     1
    Name: rep_meth, Length: 212, dtype: int64




```python
regions003 = extract003.rep_meth.groupby(extract003.g_whoregion)
regions03 = regions003.size()
regions03
```




    g_whoregion
    AFR    46
    AMR    44
    EMR    22
    EUR    53
    SEA    11
    WPR    36
    Name: rep_meth, dtype: int64




```python
print("In the year",extract003.year.unique(),",",len(count03.index),"Countries were attended to and",len(regions03.index),"Regions were attended to respectively")
```

    In the year [2003] , 212 Countries were attended to and 6 Regions were attended to respectively



```python
extract004 = dataset[dataset.year == 2004]
extract004
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>iso2</th>
      <th>iso3</th>
      <th>iso_numeric</th>
      <th>g_whoregion</th>
      <th>year</th>
      <th>rep_meth</th>
      <th>new_sp_coh</th>
      <th>new_sp_cur</th>
      <th>new_sp_cmplt</th>
      <th>new_sp_died</th>
      <th>...</th>
      <th>mdr_coh</th>
      <th>mdr_succ</th>
      <th>mdr_fail</th>
      <th>mdr_died</th>
      <th>mdr_lost</th>
      <th>xdr_coh</th>
      <th>xdr_succ</th>
      <th>xdr_fail</th>
      <th>xdr_died</th>
      <th>xdr_lost</th>
    </tr>
    <tr>
      <th>country</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>2004</td>
      <td>100</td>
      <td>9976.0</td>
      <td>7846.000000</td>
      <td>1034.000000</td>
      <td>303.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Albania</td>
      <td>AL</td>
      <td>ALB</td>
      <td>8</td>
      <td>EUR</td>
      <td>2004</td>
      <td>100</td>
      <td>201.0</td>
      <td>94.000000</td>
      <td>56.000000</td>
      <td>11.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Algeria</td>
      <td>DZ</td>
      <td>DZA</td>
      <td>12</td>
      <td>AFR</td>
      <td>2004</td>
      <td>100</td>
      <td>8405.0</td>
      <td>6229.000000</td>
      <td>1412.000000</td>
      <td>162.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>American Samoa</td>
      <td>AS</td>
      <td>ASM</td>
      <td>16</td>
      <td>WPR</td>
      <td>2004</td>
      <td>100</td>
      <td>3.0</td>
      <td>7887.186906</td>
      <td>2.000000</td>
      <td>430.904174</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Andorra</td>
      <td>AD</td>
      <td>AND</td>
      <td>20</td>
      <td>EUR</td>
      <td>2004</td>
      <td>100</td>
      <td>3.0</td>
      <td>2.000000</td>
      <td>1.000000</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <td>Wallis and Futuna Islands</td>
      <td>WF</td>
      <td>WLF</td>
      <td>876</td>
      <td>WPR</td>
      <td>2004</td>
      <td>100</td>
      <td>1.0</td>
      <td>1.000000</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>West Bank and Gaza Strip</td>
      <td>PS</td>
      <td>PSE</td>
      <td>275</td>
      <td>EMR</td>
      <td>2004</td>
      <td>100</td>
      <td>4.0</td>
      <td>2.000000</td>
      <td>964.721656</td>
      <td>1.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Yemen</td>
      <td>YE</td>
      <td>YEM</td>
      <td>887</td>
      <td>EMR</td>
      <td>2004</td>
      <td>100</td>
      <td>3501.0</td>
      <td>2382.000000</td>
      <td>483.000000</td>
      <td>91.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Zambia</td>
      <td>ZM</td>
      <td>ZMB</td>
      <td>894</td>
      <td>AFR</td>
      <td>2004</td>
      <td>100</td>
      <td>17247.0</td>
      <td>13108.000000</td>
      <td>1156.000000</td>
      <td>1363.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Zimbabwe</td>
      <td>ZW</td>
      <td>ZWE</td>
      <td>716</td>
      <td>AFR</td>
      <td>2004</td>
      <td>100</td>
      <td>14581.0</td>
      <td>7248.000000</td>
      <td>675.000000</td>
      <td>1781.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
  </tbody>
</table>
<p>211 rows × 71 columns</p>
</div>




```python
extract004.year.unique()

```




    array([2004], dtype=int64)




```python
count004 = extract004.rep_meth.groupby(extract004.index)
count04 = count004.size()
count04
```




    country
    Afghanistan                  1
    Albania                      1
    Algeria                      1
    American Samoa               1
    Andorra                      1
                                ..
    Wallis and Futuna Islands    1
    West Bank and Gaza Strip     1
    Yemen                        1
    Zambia                       1
    Zimbabwe                     1
    Name: rep_meth, Length: 211, dtype: int64




```python
regions004 = extract004.rep_meth.groupby(extract004.g_whoregion)
regions04 = regions004.size()
regions04
```




    g_whoregion
    AFR    46
    AMR    44
    EMR    22
    EUR    52
    SEA    11
    WPR    36
    Name: rep_meth, dtype: int64




```python
print("In the year",extract004.year.unique(),",",len(count04.index),"Countries were attended to and",len(regions04.index),"Regions were attended to respectively")
```

    In the year [2004] , 211 Countries were attended to and 6 Regions were attended to respectively



```python
extract005 = dataset[dataset.year == 2005]
extract005
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>iso2</th>
      <th>iso3</th>
      <th>iso_numeric</th>
      <th>g_whoregion</th>
      <th>year</th>
      <th>rep_meth</th>
      <th>new_sp_coh</th>
      <th>new_sp_cur</th>
      <th>new_sp_cmplt</th>
      <th>new_sp_died</th>
      <th>...</th>
      <th>mdr_coh</th>
      <th>mdr_succ</th>
      <th>mdr_fail</th>
      <th>mdr_died</th>
      <th>mdr_lost</th>
      <th>xdr_coh</th>
      <th>xdr_succ</th>
      <th>xdr_fail</th>
      <th>xdr_died</th>
      <th>xdr_lost</th>
    </tr>
    <tr>
      <th>country</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>2005</td>
      <td>100</td>
      <td>10013.00000</td>
      <td>8295.000000</td>
      <td>687.000000</td>
      <td>215.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Albania</td>
      <td>AL</td>
      <td>ALB</td>
      <td>8</td>
      <td>EUR</td>
      <td>2005</td>
      <td>100</td>
      <td>196.00000</td>
      <td>85.000000</td>
      <td>69.000000</td>
      <td>8.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Algeria</td>
      <td>DZ</td>
      <td>DZA</td>
      <td>12</td>
      <td>AFR</td>
      <td>2005</td>
      <td>100</td>
      <td>8379.00000</td>
      <td>6180.000000</td>
      <td>1100.000000</td>
      <td>164.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>American Samoa</td>
      <td>AS</td>
      <td>ASM</td>
      <td>16</td>
      <td>WPR</td>
      <td>2005</td>
      <td>100</td>
      <td>4.00000</td>
      <td>3.000000</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Andorra</td>
      <td>AD</td>
      <td>AND</td>
      <td>20</td>
      <td>EUR</td>
      <td>2005</td>
      <td>100</td>
      <td>5.00000</td>
      <td>4.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <td>Wallis and Futuna Islands</td>
      <td>WF</td>
      <td>WLF</td>
      <td>876</td>
      <td>WPR</td>
      <td>2005</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>West Bank and Gaza Strip</td>
      <td>PS</td>
      <td>PSE</td>
      <td>275</td>
      <td>EMR</td>
      <td>2005</td>
      <td>100</td>
      <td>12.00000</td>
      <td>7.000000</td>
      <td>5.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Yemen</td>
      <td>YE</td>
      <td>YEM</td>
      <td>887</td>
      <td>EMR</td>
      <td>2005</td>
      <td>100</td>
      <td>3566.00000</td>
      <td>2464.000000</td>
      <td>400.000000</td>
      <td>106.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Zambia</td>
      <td>ZM</td>
      <td>ZMB</td>
      <td>894</td>
      <td>AFR</td>
      <td>2005</td>
      <td>100</td>
      <td>14857.00000</td>
      <td>11290.000000</td>
      <td>1180.000000</td>
      <td>1178.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Zimbabwe</td>
      <td>ZW</td>
      <td>ZWE</td>
      <td>716</td>
      <td>AFR</td>
      <td>2005</td>
      <td>100</td>
      <td>12860.00000</td>
      <td>7554.000000</td>
      <td>1161.000000</td>
      <td>1479.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
  </tbody>
</table>
<p>213 rows × 71 columns</p>
</div>




```python
extract005.year.unique()
```




    array([2005], dtype=int64)




```python
count005 = extract005.rep_meth.groupby(extract005.index)
count05 = count005.size()
count05
```




    country
    Afghanistan                  1
    Albania                      1
    Algeria                      1
    American Samoa               1
    Andorra                      1
                                ..
    Wallis and Futuna Islands    1
    West Bank and Gaza Strip     1
    Yemen                        1
    Zambia                       1
    Zimbabwe                     1
    Name: rep_meth, Length: 213, dtype: int64




```python
regions005 = extract005.rep_meth.groupby(extract005.g_whoregion)
regions05 = regions005.size()
regions05
```




    g_whoregion
    AFR    46
    AMR    44
    EMR    22
    EUR    54
    SEA    11
    WPR    36
    Name: rep_meth, dtype: int64




```python
print("In the year",extract005.year.unique(),",",len(count05.index),"Countries were attended to and",len(regions05.index),"Regions were attended to respectively")
```

    In the year [2005] , 213 Countries were attended to and 6 Regions were attended to respectively



```python
extract006 = dataset[dataset.year == 2006]
extract006
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>iso2</th>
      <th>iso3</th>
      <th>iso_numeric</th>
      <th>g_whoregion</th>
      <th>year</th>
      <th>rep_meth</th>
      <th>new_sp_coh</th>
      <th>new_sp_cur</th>
      <th>new_sp_cmplt</th>
      <th>new_sp_died</th>
      <th>...</th>
      <th>mdr_coh</th>
      <th>mdr_succ</th>
      <th>mdr_fail</th>
      <th>mdr_died</th>
      <th>mdr_lost</th>
      <th>xdr_coh</th>
      <th>xdr_succ</th>
      <th>xdr_fail</th>
      <th>xdr_died</th>
      <th>xdr_lost</th>
    </tr>
    <tr>
      <th>country</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>2006</td>
      <td>100</td>
      <td>12468.0</td>
      <td>9921.0</td>
      <td>608.0</td>
      <td>257.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Albania</td>
      <td>AL</td>
      <td>ALB</td>
      <td>8</td>
      <td>EUR</td>
      <td>2006</td>
      <td>100</td>
      <td>186.0</td>
      <td>91.0</td>
      <td>77.0</td>
      <td>2.000000</td>
      <td>...</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Algeria</td>
      <td>DZ</td>
      <td>DZA</td>
      <td>12</td>
      <td>AFR</td>
      <td>2006</td>
      <td>100</td>
      <td>8285.0</td>
      <td>7148.0</td>
      <td>374.0</td>
      <td>156.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>American Samoa</td>
      <td>AS</td>
      <td>ASM</td>
      <td>16</td>
      <td>WPR</td>
      <td>2006</td>
      <td>100</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Andorra</td>
      <td>AD</td>
      <td>AND</td>
      <td>20</td>
      <td>EUR</td>
      <td>2006</td>
      <td>100</td>
      <td>8.0</td>
      <td>1.0</td>
      <td>5.0</td>
      <td>430.904174</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <td>Wallis and Futuna Islands</td>
      <td>WF</td>
      <td>WLF</td>
      <td>876</td>
      <td>WPR</td>
      <td>2006</td>
      <td>100</td>
      <td>4.0</td>
      <td>2.0</td>
      <td>2.0</td>
      <td>0.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>West Bank and Gaza Strip</td>
      <td>PS</td>
      <td>PSE</td>
      <td>275</td>
      <td>EMR</td>
      <td>2006</td>
      <td>100</td>
      <td>16.0</td>
      <td>8.0</td>
      <td>7.0</td>
      <td>1.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Yemen</td>
      <td>YE</td>
      <td>YEM</td>
      <td>887</td>
      <td>EMR</td>
      <td>2006</td>
      <td>100</td>
      <td>3337.0</td>
      <td>2474.0</td>
      <td>289.0</td>
      <td>98.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Zambia</td>
      <td>ZM</td>
      <td>ZMB</td>
      <td>894</td>
      <td>AFR</td>
      <td>2006</td>
      <td>100</td>
      <td>14025.0</td>
      <td>10762.0</td>
      <td>1149.0</td>
      <td>930.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Zimbabwe</td>
      <td>ZW</td>
      <td>ZWE</td>
      <td>716</td>
      <td>AFR</td>
      <td>2006</td>
      <td>100</td>
      <td>16205.0</td>
      <td>8757.0</td>
      <td>970.0</td>
      <td>1235.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
  </tbody>
</table>
<p>213 rows × 71 columns</p>
</div>




```python
extract006.year.unique()
```




    array([2006], dtype=int64)




```python
count006 = extract006.rep_meth.groupby(extract006.index)
count06 = count006.size()
count06
```




    country
    Afghanistan                  1
    Albania                      1
    Algeria                      1
    American Samoa               1
    Andorra                      1
                                ..
    Wallis and Futuna Islands    1
    West Bank and Gaza Strip     1
    Yemen                        1
    Zambia                       1
    Zimbabwe                     1
    Name: rep_meth, Length: 213, dtype: int64




```python
regions006 = extract006.rep_meth.groupby(extract006.g_whoregion)
regions06 = regions006.size()
regions06
```




    g_whoregion
    AFR    46
    AMR    44
    EMR    22
    EUR    54
    SEA    11
    WPR    36
    Name: rep_meth, dtype: int64




```python
print("In the year",extract006.year.unique(),",",len(count06.index),"Countries were attended to and",len(regions06.index),"were attended to respectively")
```

    In the year [2006] , 213 Countries were attended to and 6 were attended to respectively



```python
extract007 = dataset[dataset.year == 2007]
extract007
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>iso2</th>
      <th>iso3</th>
      <th>iso_numeric</th>
      <th>g_whoregion</th>
      <th>year</th>
      <th>rep_meth</th>
      <th>new_sp_coh</th>
      <th>new_sp_cur</th>
      <th>new_sp_cmplt</th>
      <th>new_sp_died</th>
      <th>...</th>
      <th>mdr_coh</th>
      <th>mdr_succ</th>
      <th>mdr_fail</th>
      <th>mdr_died</th>
      <th>mdr_lost</th>
      <th>xdr_coh</th>
      <th>xdr_succ</th>
      <th>xdr_fail</th>
      <th>xdr_died</th>
      <th>xdr_lost</th>
    </tr>
    <tr>
      <th>country</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>2007</td>
      <td>100</td>
      <td>13213.00000</td>
      <td>10859.000000</td>
      <td>663.000000</td>
      <td>260.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Albania</td>
      <td>AL</td>
      <td>ALB</td>
      <td>8</td>
      <td>EUR</td>
      <td>2007</td>
      <td>100</td>
      <td>181.00000</td>
      <td>90.000000</td>
      <td>63.000000</td>
      <td>8.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Algeria</td>
      <td>DZ</td>
      <td>DZA</td>
      <td>12</td>
      <td>AFR</td>
      <td>2007</td>
      <td>100</td>
      <td>8510.00000</td>
      <td>6699.000000</td>
      <td>930.000000</td>
      <td>180.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>American Samoa</td>
      <td>AS</td>
      <td>ASM</td>
      <td>16</td>
      <td>WPR</td>
      <td>2007</td>
      <td>102</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Andorra</td>
      <td>AD</td>
      <td>AND</td>
      <td>20</td>
      <td>EUR</td>
      <td>2007</td>
      <td>101</td>
      <td>2.00000</td>
      <td>2.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <td>Wallis and Futuna Islands</td>
      <td>WF</td>
      <td>WLF</td>
      <td>876</td>
      <td>WPR</td>
      <td>2007</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>West Bank and Gaza Strip</td>
      <td>PS</td>
      <td>PSE</td>
      <td>275</td>
      <td>EMR</td>
      <td>2007</td>
      <td>100</td>
      <td>14.00000</td>
      <td>7.000000</td>
      <td>6.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Yemen</td>
      <td>YE</td>
      <td>YEM</td>
      <td>887</td>
      <td>EMR</td>
      <td>2007</td>
      <td>100</td>
      <td>3523.00000</td>
      <td>2644.000000</td>
      <td>323.000000</td>
      <td>97.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Zambia</td>
      <td>ZM</td>
      <td>ZMB</td>
      <td>894</td>
      <td>AFR</td>
      <td>2007</td>
      <td>102</td>
      <td>13378.00000</td>
      <td>10447.000000</td>
      <td>882.000000</td>
      <td>855.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Zimbabwe</td>
      <td>ZW</td>
      <td>ZWE</td>
      <td>716</td>
      <td>AFR</td>
      <td>2007</td>
      <td>100</td>
      <td>10583.00000</td>
      <td>7455.000000</td>
      <td>768.000000</td>
      <td>872.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
  </tbody>
</table>
<p>213 rows × 71 columns</p>
</div>




```python
extract007.year.unique()
```




    array([2007], dtype=int64)




```python
count007 = extract007.rep_meth.groupby(extract007.index)
count07 = count007.size()
count07
```




    country
    Afghanistan                  1
    Albania                      1
    Algeria                      1
    American Samoa               1
    Andorra                      1
                                ..
    Wallis and Futuna Islands    1
    West Bank and Gaza Strip     1
    Yemen                        1
    Zambia                       1
    Zimbabwe                     1
    Name: rep_meth, Length: 213, dtype: int64




```python
regions007 = extract007.rep_meth.groupby(extract007.g_whoregion)
regions07 = regions007.size()
regions07
```




    g_whoregion
    AFR    46
    AMR    44
    EMR    22
    EUR    54
    SEA    11
    WPR    36
    Name: rep_meth, dtype: int64




```python
print("In the year",extract007.year.unique(),",",len(count07.index),"Countries were attended to and",len(regions07.index),"Regions were attended to respectively")
```

    In the year [2007] , 213 Countries were attended to and 6 Regions were attended to respectively



```python
extract008 = dataset[dataset.year == 2008]
extract008
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>iso2</th>
      <th>iso3</th>
      <th>iso_numeric</th>
      <th>g_whoregion</th>
      <th>year</th>
      <th>rep_meth</th>
      <th>new_sp_coh</th>
      <th>new_sp_cur</th>
      <th>new_sp_cmplt</th>
      <th>new_sp_died</th>
      <th>...</th>
      <th>mdr_coh</th>
      <th>mdr_succ</th>
      <th>mdr_fail</th>
      <th>mdr_died</th>
      <th>mdr_lost</th>
      <th>xdr_coh</th>
      <th>xdr_succ</th>
      <th>xdr_fail</th>
      <th>xdr_died</th>
      <th>xdr_lost</th>
    </tr>
    <tr>
      <th>country</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>2008</td>
      <td>100</td>
      <td>13136.0</td>
      <td>10936.0</td>
      <td>593.0</td>
      <td>267.0</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Albania</td>
      <td>AL</td>
      <td>ALB</td>
      <td>8</td>
      <td>EUR</td>
      <td>2008</td>
      <td>100</td>
      <td>170.0</td>
      <td>88.0</td>
      <td>66.0</td>
      <td>6.0</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Algeria</td>
      <td>DZ</td>
      <td>DZA</td>
      <td>12</td>
      <td>AFR</td>
      <td>2008</td>
      <td>102</td>
      <td>8190.0</td>
      <td>6584.0</td>
      <td>803.0</td>
      <td>142.0</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>American Samoa</td>
      <td>AS</td>
      <td>ASM</td>
      <td>16</td>
      <td>WPR</td>
      <td>2008</td>
      <td>102</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>Andorra</td>
      <td>AD</td>
      <td>AND</td>
      <td>20</td>
      <td>EUR</td>
      <td>2008</td>
      <td>101</td>
      <td>3.0</td>
      <td>1.0</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <td>Wallis and Futuna Islands</td>
      <td>WF</td>
      <td>WLF</td>
      <td>876</td>
      <td>WPR</td>
      <td>2008</td>
      <td>102</td>
      <td>3.0</td>
      <td>3.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>West Bank and Gaza Strip</td>
      <td>PS</td>
      <td>PSE</td>
      <td>275</td>
      <td>EMR</td>
      <td>2008</td>
      <td>100</td>
      <td>16.0</td>
      <td>6.0</td>
      <td>9.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>Yemen</td>
      <td>YE</td>
      <td>YEM</td>
      <td>887</td>
      <td>EMR</td>
      <td>2008</td>
      <td>100</td>
      <td>3540.0</td>
      <td>2671.0</td>
      <td>334.0</td>
      <td>97.0</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>Zambia</td>
      <td>ZM</td>
      <td>ZMB</td>
      <td>894</td>
      <td>AFR</td>
      <td>2008</td>
      <td>100</td>
      <td>13173.0</td>
      <td>10875.0</td>
      <td>671.0</td>
      <td>721.0</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Zimbabwe</td>
      <td>ZW</td>
      <td>ZWE</td>
      <td>716</td>
      <td>AFR</td>
      <td>2008</td>
      <td>100</td>
      <td>10370.0</td>
      <td>6973.0</td>
      <td>734.0</td>
      <td>936.0</td>
      <td>...</td>
      <td>0.000000</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>0.00000</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
  </tbody>
</table>
<p>213 rows × 71 columns</p>
</div>




```python
extract008.year.unique()
```




    array([2008], dtype=int64)




```python
count008 = extract008.rep_meth.groupby(extract008.index)
count08 = count008.size()
count08
```




    country
    Afghanistan                  1
    Albania                      1
    Algeria                      1
    American Samoa               1
    Andorra                      1
                                ..
    Wallis and Futuna Islands    1
    West Bank and Gaza Strip     1
    Yemen                        1
    Zambia                       1
    Zimbabwe                     1
    Name: rep_meth, Length: 213, dtype: int64




```python
regions008 = extract008.rep_meth.groupby(extract008.g_whoregion)
regions08 = regions008.size()
regions08
```




    g_whoregion
    AFR    46
    AMR    44
    EMR    22
    EUR    54
    SEA    11
    WPR    36
    Name: rep_meth, dtype: int64




```python
print("In the year",extract008.year.unique(),",",len(count08.index),"Countries were attended to and",len(regions08.index),"Regions were attended to respectively")
```

    In the year [2008] , 213 Countries were attended to and 6 Regions were attended to respectively



```python
extract009 = dataset[dataset.year == 2009]
extract009
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>iso2</th>
      <th>iso3</th>
      <th>iso_numeric</th>
      <th>g_whoregion</th>
      <th>year</th>
      <th>rep_meth</th>
      <th>new_sp_coh</th>
      <th>new_sp_cur</th>
      <th>new_sp_cmplt</th>
      <th>new_sp_died</th>
      <th>...</th>
      <th>mdr_coh</th>
      <th>mdr_succ</th>
      <th>mdr_fail</th>
      <th>mdr_died</th>
      <th>mdr_lost</th>
      <th>xdr_coh</th>
      <th>xdr_succ</th>
      <th>xdr_fail</th>
      <th>xdr_died</th>
      <th>xdr_lost</th>
    </tr>
    <tr>
      <th>country</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>2009</td>
      <td>100</td>
      <td>12497.00000</td>
      <td>10323.000000</td>
      <td>483.000000</td>
      <td>247.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Albania</td>
      <td>AL</td>
      <td>ALB</td>
      <td>8</td>
      <td>EUR</td>
      <td>2009</td>
      <td>100</td>
      <td>171.00000</td>
      <td>110.000000</td>
      <td>43.000000</td>
      <td>4.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>Algeria</td>
      <td>DZ</td>
      <td>DZA</td>
      <td>12</td>
      <td>AFR</td>
      <td>2009</td>
      <td>102</td>
      <td>8438.00000</td>
      <td>6864.000000</td>
      <td>854.000000</td>
      <td>145.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>American Samoa</td>
      <td>AS</td>
      <td>ASM</td>
      <td>16</td>
      <td>WPR</td>
      <td>2009</td>
      <td>100</td>
      <td>3.00000</td>
      <td>0.000000</td>
      <td>3.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Andorra</td>
      <td>AD</td>
      <td>AND</td>
      <td>20</td>
      <td>EUR</td>
      <td>2009</td>
      <td>102</td>
      <td>3.00000</td>
      <td>1.000000</td>
      <td>2.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <td>Wallis and Futuna Islands</td>
      <td>WF</td>
      <td>WLF</td>
      <td>876</td>
      <td>WPR</td>
      <td>2009</td>
      <td>102</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>West Bank and Gaza Strip</td>
      <td>PS</td>
      <td>PSE</td>
      <td>275</td>
      <td>EMR</td>
      <td>2009</td>
      <td>100</td>
      <td>11.00000</td>
      <td>2.000000</td>
      <td>7.000000</td>
      <td>1.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>Yemen</td>
      <td>YE</td>
      <td>YEM</td>
      <td>887</td>
      <td>EMR</td>
      <td>2009</td>
      <td>100</td>
      <td>3557.00000</td>
      <td>2804.000000</td>
      <td>316.000000</td>
      <td>113.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Zambia</td>
      <td>ZM</td>
      <td>ZMB</td>
      <td>894</td>
      <td>AFR</td>
      <td>2009</td>
      <td>102</td>
      <td>12995.00000</td>
      <td>10983.000000</td>
      <td>777.000000</td>
      <td>722.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Zimbabwe</td>
      <td>ZW</td>
      <td>ZWE</td>
      <td>716</td>
      <td>AFR</td>
      <td>2009</td>
      <td>100</td>
      <td>10195.00000</td>
      <td>7131.000000</td>
      <td>868.000000</td>
      <td>807.000000</td>
      <td>...</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
  </tbody>
</table>
<p>215 rows × 71 columns</p>
</div>




```python
extract009.year.unique()
```




    array([2009], dtype=int64)




```python
count009 = extract009.rep_meth.groupby(extract009.index)
count09 = count009.size()
count09
```




    country
    Afghanistan                  1
    Albania                      1
    Algeria                      1
    American Samoa               1
    Andorra                      1
                                ..
    Wallis and Futuna Islands    1
    West Bank and Gaza Strip     1
    Yemen                        1
    Zambia                       1
    Zimbabwe                     1
    Name: rep_meth, Length: 215, dtype: int64




```python
regions009 = extract009.rep_meth.groupby(extract009.g_whoregion)
regions09 = regions009.size()
regions09
```




    g_whoregion
    AFR    46
    AMR    46
    EMR    22
    EUR    54
    SEA    11
    WPR    36
    Name: rep_meth, dtype: int64




```python
print("In the year",extract009.year.unique(),",",len(count09.index),"Countries were attended to and",len(regions09.index),"Regions were attended to respectively")
```

    In the year [2009] , 215 Countries were attended to and 6 Regions were attended to respectively



```python
extract010 = dataset[dataset.year == 2010]
extract010
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>iso2</th>
      <th>iso3</th>
      <th>iso_numeric</th>
      <th>g_whoregion</th>
      <th>year</th>
      <th>rep_meth</th>
      <th>new_sp_coh</th>
      <th>new_sp_cur</th>
      <th>new_sp_cmplt</th>
      <th>new_sp_died</th>
      <th>...</th>
      <th>mdr_coh</th>
      <th>mdr_succ</th>
      <th>mdr_fail</th>
      <th>mdr_died</th>
      <th>mdr_lost</th>
      <th>xdr_coh</th>
      <th>xdr_succ</th>
      <th>xdr_fail</th>
      <th>xdr_died</th>
      <th>xdr_lost</th>
    </tr>
    <tr>
      <th>country</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>2010</td>
      <td>100</td>
      <td>12947.0</td>
      <td>11175.000000</td>
      <td>446.000000</td>
      <td>254.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Albania</td>
      <td>AL</td>
      <td>ALB</td>
      <td>8</td>
      <td>EUR</td>
      <td>2010</td>
      <td>100</td>
      <td>145.0</td>
      <td>71.000000</td>
      <td>61.000000</td>
      <td>4.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>Algeria</td>
      <td>DZ</td>
      <td>DZA</td>
      <td>12</td>
      <td>AFR</td>
      <td>2010</td>
      <td>102</td>
      <td>7894.0</td>
      <td>6219.000000</td>
      <td>821.000000</td>
      <td>177.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>American Samoa</td>
      <td>AS</td>
      <td>ASM</td>
      <td>16</td>
      <td>WPR</td>
      <td>2010</td>
      <td>102</td>
      <td>0.0</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Andorra</td>
      <td>AD</td>
      <td>AND</td>
      <td>20</td>
      <td>EUR</td>
      <td>2010</td>
      <td>102</td>
      <td>0.0</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <td>Wallis and Futuna Islands</td>
      <td>WF</td>
      <td>WLF</td>
      <td>876</td>
      <td>WPR</td>
      <td>2010</td>
      <td>102</td>
      <td>2.0</td>
      <td>0.000000</td>
      <td>2.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>West Bank and Gaza Strip</td>
      <td>PS</td>
      <td>PSE</td>
      <td>275</td>
      <td>EMR</td>
      <td>2010</td>
      <td>100</td>
      <td>12.0</td>
      <td>1.000000</td>
      <td>9.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>Yemen</td>
      <td>YE</td>
      <td>YEM</td>
      <td>887</td>
      <td>EMR</td>
      <td>2010</td>
      <td>100</td>
      <td>3584.0</td>
      <td>2775.000000</td>
      <td>334.000000</td>
      <td>94.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Zambia</td>
      <td>ZM</td>
      <td>ZMB</td>
      <td>894</td>
      <td>AFR</td>
      <td>2010</td>
      <td>102</td>
      <td>12639.0</td>
      <td>10532.000000</td>
      <td>775.000000</td>
      <td>722.000000</td>
      <td>...</td>
      <td>56.000000</td>
      <td>20.000000</td>
      <td>3.000000</td>
      <td>2.000000</td>
      <td>3.000000</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Zimbabwe</td>
      <td>ZW</td>
      <td>ZWE</td>
      <td>716</td>
      <td>AFR</td>
      <td>2010</td>
      <td>100</td>
      <td>11654.0</td>
      <td>8377.000000</td>
      <td>1116.000000</td>
      <td>917.000000</td>
      <td>...</td>
      <td>6.000000</td>
      <td>4.000000</td>
      <td>0.000000</td>
      <td>2.000000</td>
      <td>0.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
  </tbody>
</table>
<p>216 rows × 71 columns</p>
</div>




```python
extract010.year.unique()
```




    array([2010], dtype=int64)




```python
count010 = extract010.rep_meth.groupby(extract010.index)
count10 = count010.size()
count10
```




    country
    Afghanistan                  1
    Albania                      1
    Algeria                      1
    American Samoa               1
    Andorra                      1
                                ..
    Wallis and Futuna Islands    1
    West Bank and Gaza Strip     1
    Yemen                        1
    Zambia                       1
    Zimbabwe                     1
    Name: rep_meth, Length: 216, dtype: int64




```python
regions010 = extract010.rep_meth.groupby(extract010.g_whoregion)
regions10 = regions010.size()
regions10
```




    g_whoregion
    AFR    47
    AMR    46
    EMR    22
    EUR    54
    SEA    11
    WPR    36
    Name: rep_meth, dtype: int64




```python
print("In the year",extract010.year.unique(),",",len(count10.index),"Countries were attended to and",len(regions10.index),"Regions were attended to respectively")
```

    In the year [2010] , 216 Countries were attended to and 6 Regions were attended to respectively



```python
extract011 = dataset[dataset.year == 2011]
extract011
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>iso2</th>
      <th>iso3</th>
      <th>iso_numeric</th>
      <th>g_whoregion</th>
      <th>year</th>
      <th>rep_meth</th>
      <th>new_sp_coh</th>
      <th>new_sp_cur</th>
      <th>new_sp_cmplt</th>
      <th>new_sp_died</th>
      <th>...</th>
      <th>mdr_coh</th>
      <th>mdr_succ</th>
      <th>mdr_fail</th>
      <th>mdr_died</th>
      <th>mdr_lost</th>
      <th>xdr_coh</th>
      <th>xdr_succ</th>
      <th>xdr_fail</th>
      <th>xdr_died</th>
      <th>xdr_lost</th>
    </tr>
    <tr>
      <th>country</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>2011</td>
      <td>100</td>
      <td>13789.00000</td>
      <td>12067.000000</td>
      <td>534.000000</td>
      <td>217.000000</td>
      <td>...</td>
      <td>21.000000</td>
      <td>14.000000</td>
      <td>0.000000</td>
      <td>2.000000</td>
      <td>0.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>Albania</td>
      <td>AL</td>
      <td>ALB</td>
      <td>8</td>
      <td>EUR</td>
      <td>2011</td>
      <td>100</td>
      <td>180.00000</td>
      <td>117.000000</td>
      <td>51.000000</td>
      <td>3.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Algeria</td>
      <td>DZ</td>
      <td>DZA</td>
      <td>12</td>
      <td>AFR</td>
      <td>2011</td>
      <td>102</td>
      <td>7364.00000</td>
      <td>5969.000000</td>
      <td>807.000000</td>
      <td>136.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>American Samoa</td>
      <td>AS</td>
      <td>ASM</td>
      <td>16</td>
      <td>WPR</td>
      <td>2011</td>
      <td>102</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Andorra</td>
      <td>AD</td>
      <td>AND</td>
      <td>20</td>
      <td>EUR</td>
      <td>2011</td>
      <td>102</td>
      <td>1.00000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <td>Wallis and Futuna Islands</td>
      <td>WF</td>
      <td>WLF</td>
      <td>876</td>
      <td>WPR</td>
      <td>2011</td>
      <td>102</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>0.000000</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>West Bank and Gaza Strip</td>
      <td>PS</td>
      <td>PSE</td>
      <td>275</td>
      <td>EMR</td>
      <td>2011</td>
      <td>100</td>
      <td>11.00000</td>
      <td>2.000000</td>
      <td>9.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Yemen</td>
      <td>YE</td>
      <td>YEM</td>
      <td>887</td>
      <td>EMR</td>
      <td>2011</td>
      <td>100</td>
      <td>3174.00000</td>
      <td>2517.000000</td>
      <td>285.000000</td>
      <td>79.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>Zambia</td>
      <td>ZM</td>
      <td>ZMB</td>
      <td>894</td>
      <td>AFR</td>
      <td>2011</td>
      <td>102</td>
      <td>12711.00000</td>
      <td>10463.000000</td>
      <td>671.000000</td>
      <td>561.000000</td>
      <td>...</td>
      <td>79.000000</td>
      <td>23.000000</td>
      <td>2.000000</td>
      <td>2.000000</td>
      <td>3.000000</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Zimbabwe</td>
      <td>ZW</td>
      <td>ZWE</td>
      <td>716</td>
      <td>AFR</td>
      <td>2011</td>
      <td>100</td>
      <td>12596.00000</td>
      <td>9208.000000</td>
      <td>995.000000</td>
      <td>1019.000000</td>
      <td>...</td>
      <td>70.000000</td>
      <td>57.000000</td>
      <td>0.000000</td>
      <td>9.000000</td>
      <td>2.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
  </tbody>
</table>
<p>216 rows × 71 columns</p>
</div>




```python
extract011.year.unique()
```




    array([2011], dtype=int64)




```python
count011 = extract011.rep_meth.groupby(extract011.index)
count11 = count011.size()
count11
```




    country
    Afghanistan                  1
    Albania                      1
    Algeria                      1
    American Samoa               1
    Andorra                      1
                                ..
    Wallis and Futuna Islands    1
    West Bank and Gaza Strip     1
    Yemen                        1
    Zambia                       1
    Zimbabwe                     1
    Name: rep_meth, Length: 216, dtype: int64




```python
regions011 = extract011.rep_meth.groupby(extract011.g_whoregion)
regions11 = regions011.size()
regions11
```




    g_whoregion
    AFR    47
    AMR    46
    EMR    22
    EUR    54
    SEA    11
    WPR    36
    Name: rep_meth, dtype: int64




```python
print("In the year",extract011.year.unique(),",",len(count11.index),"Countries were attended to and",len(regions11.index),"Regions were attended to respectively")
```

    In the year [2011] , 216 Countries were attended to and 6 Regions were attended to respectively



```python
extract012 = dataset[dataset.year == 2012]
extract012
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>iso2</th>
      <th>iso3</th>
      <th>iso_numeric</th>
      <th>g_whoregion</th>
      <th>year</th>
      <th>rep_meth</th>
      <th>new_sp_coh</th>
      <th>new_sp_cur</th>
      <th>new_sp_cmplt</th>
      <th>new_sp_died</th>
      <th>...</th>
      <th>mdr_coh</th>
      <th>mdr_succ</th>
      <th>mdr_fail</th>
      <th>mdr_died</th>
      <th>mdr_lost</th>
      <th>xdr_coh</th>
      <th>xdr_succ</th>
      <th>xdr_fail</th>
      <th>xdr_died</th>
      <th>xdr_lost</th>
    </tr>
    <tr>
      <th>country</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>2012</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>38.000000</td>
      <td>27.000000</td>
      <td>0.000000</td>
      <td>6.000000</td>
      <td>3.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>Albania</td>
      <td>AL</td>
      <td>ALB</td>
      <td>8</td>
      <td>EUR</td>
      <td>2012</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Algeria</td>
      <td>DZ</td>
      <td>DZA</td>
      <td>12</td>
      <td>AFR</td>
      <td>2012</td>
      <td>102</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>American Samoa</td>
      <td>AS</td>
      <td>ASM</td>
      <td>16</td>
      <td>WPR</td>
      <td>2012</td>
      <td>102</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Andorra</td>
      <td>AD</td>
      <td>AND</td>
      <td>20</td>
      <td>EUR</td>
      <td>2012</td>
      <td>102</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>0.000000</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>0.00000</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <td>Wallis and Futuna Islands</td>
      <td>WF</td>
      <td>WLF</td>
      <td>876</td>
      <td>WPR</td>
      <td>2012</td>
      <td>102</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>0.000000</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>West Bank and Gaza Strip</td>
      <td>PS</td>
      <td>PSE</td>
      <td>275</td>
      <td>EMR</td>
      <td>2012</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>Yemen</td>
      <td>YE</td>
      <td>YEM</td>
      <td>887</td>
      <td>EMR</td>
      <td>2012</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Zambia</td>
      <td>ZM</td>
      <td>ZMB</td>
      <td>894</td>
      <td>AFR</td>
      <td>2012</td>
      <td>102</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>100.000000</td>
      <td>27.000000</td>
      <td>2.000000</td>
      <td>2.000000</td>
      <td>5.000000</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Zimbabwe</td>
      <td>ZW</td>
      <td>ZWE</td>
      <td>716</td>
      <td>AFR</td>
      <td>2012</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>234.000000</td>
      <td>175.000000</td>
      <td>7.000000</td>
      <td>26.000000</td>
      <td>18.000000</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
  </tbody>
</table>
<p>216 rows × 71 columns</p>
</div>




```python
extract012.year.unique()
```




    array([2012], dtype=int64)




```python
count012 = extract012.rep_meth.groupby(extract012.index)
count12 = count012.size()
count12
```




    country
    Afghanistan                  1
    Albania                      1
    Algeria                      1
    American Samoa               1
    Andorra                      1
                                ..
    Wallis and Futuna Islands    1
    West Bank and Gaza Strip     1
    Yemen                        1
    Zambia                       1
    Zimbabwe                     1
    Name: rep_meth, Length: 216, dtype: int64




```python
regions012 = extract012.rep_meth.groupby(extract012.g_whoregion)
regions12 = regions012.size()
regions12
```




    g_whoregion
    AFR    47
    AMR    46
    EMR    22
    EUR    54
    SEA    11
    WPR    36
    Name: rep_meth, dtype: int64




```python
print("In the year",extract012.year.unique(),",",len(count12.index),"Countries were attended to and",len(regions012),"Regions were attended to respectively")
```

    In the year [2012] , 216 Countries were attended to and 6 Regions were attended to respectively



```python
extract013 = dataset[dataset.year == 2013]
extract013
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>iso2</th>
      <th>iso3</th>
      <th>iso_numeric</th>
      <th>g_whoregion</th>
      <th>year</th>
      <th>rep_meth</th>
      <th>new_sp_coh</th>
      <th>new_sp_cur</th>
      <th>new_sp_cmplt</th>
      <th>new_sp_died</th>
      <th>...</th>
      <th>mdr_coh</th>
      <th>mdr_succ</th>
      <th>mdr_fail</th>
      <th>mdr_died</th>
      <th>mdr_lost</th>
      <th>xdr_coh</th>
      <th>xdr_succ</th>
      <th>xdr_fail</th>
      <th>xdr_died</th>
      <th>xdr_lost</th>
    </tr>
    <tr>
      <th>country</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>2013</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>46.000000</td>
      <td>29.000000</td>
      <td>1.000000</td>
      <td>6.000000</td>
      <td>9.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>Albania</td>
      <td>AL</td>
      <td>ALB</td>
      <td>8</td>
      <td>EUR</td>
      <td>2013</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Algeria</td>
      <td>DZ</td>
      <td>DZA</td>
      <td>12</td>
      <td>AFR</td>
      <td>2013</td>
      <td>102</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>American Samoa</td>
      <td>AS</td>
      <td>ASM</td>
      <td>16</td>
      <td>WPR</td>
      <td>2013</td>
      <td>102</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Andorra</td>
      <td>AD</td>
      <td>AND</td>
      <td>20</td>
      <td>EUR</td>
      <td>2013</td>
      <td>102</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <td>Wallis and Futuna Islands</td>
      <td>WF</td>
      <td>WLF</td>
      <td>876</td>
      <td>WPR</td>
      <td>2013</td>
      <td>102</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>2.00000</td>
      <td>2.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>West Bank and Gaza Strip</td>
      <td>PS</td>
      <td>PSE</td>
      <td>275</td>
      <td>EMR</td>
      <td>2013</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>Yemen</td>
      <td>YE</td>
      <td>YEM</td>
      <td>887</td>
      <td>EMR</td>
      <td>2013</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>9.000000</td>
      <td>6.000000</td>
      <td>30.547632</td>
      <td>1.000000</td>
      <td>2.000000</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Zambia</td>
      <td>ZM</td>
      <td>ZMB</td>
      <td>894</td>
      <td>AFR</td>
      <td>2013</td>
      <td>102</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>58.000000</td>
      <td>19.000000</td>
      <td>2.000000</td>
      <td>7.000000</td>
      <td>27.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>Zimbabwe</td>
      <td>ZW</td>
      <td>ZWE</td>
      <td>716</td>
      <td>AFR</td>
      <td>2013</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>351.000000</td>
      <td>207.000000</td>
      <td>1.000000</td>
      <td>43.000000</td>
      <td>14.000000</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
  </tbody>
</table>
<p>216 rows × 71 columns</p>
</div>




```python
extract013.year.unique()
```




    array([2013], dtype=int64)




```python
count013 = extract013.rep_meth.groupby(extract013.index)
count13 = count013.size()
count13
```




    country
    Afghanistan                  1
    Albania                      1
    Algeria                      1
    American Samoa               1
    Andorra                      1
                                ..
    Wallis and Futuna Islands    1
    West Bank and Gaza Strip     1
    Yemen                        1
    Zambia                       1
    Zimbabwe                     1
    Name: rep_meth, Length: 216, dtype: int64




```python
regions013 = extract013.rep_meth.groupby(extract013.g_whoregion)
regions13 = regions013.size()
regions13
```




    g_whoregion
    AFR    47
    AMR    46
    EMR    22
    EUR    54
    SEA    11
    WPR    36
    Name: rep_meth, dtype: int64




```python
print("In the year",extract013.year.unique(),",",len(count13.index),"Countries were attended to and",len(regions13.index),"Regions were attended to respectively")
```

    In the year [2013] , 216 Countries were attended to and 6 Regions were attended to respectively



```python
extract014 = dataset[dataset.year == 2014]
extract014
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>iso2</th>
      <th>iso3</th>
      <th>iso_numeric</th>
      <th>g_whoregion</th>
      <th>year</th>
      <th>rep_meth</th>
      <th>new_sp_coh</th>
      <th>new_sp_cur</th>
      <th>new_sp_cmplt</th>
      <th>new_sp_died</th>
      <th>...</th>
      <th>mdr_coh</th>
      <th>mdr_succ</th>
      <th>mdr_fail</th>
      <th>mdr_died</th>
      <th>mdr_lost</th>
      <th>xdr_coh</th>
      <th>xdr_succ</th>
      <th>xdr_fail</th>
      <th>xdr_died</th>
      <th>xdr_lost</th>
    </tr>
    <tr>
      <th>country</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>2014</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>86.000000</td>
      <td>56.000000</td>
      <td>0.000000</td>
      <td>10.000000</td>
      <td>20.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>Albania</td>
      <td>AL</td>
      <td>ALB</td>
      <td>8</td>
      <td>EUR</td>
      <td>2014</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Algeria</td>
      <td>DZ</td>
      <td>DZA</td>
      <td>12</td>
      <td>AFR</td>
      <td>2014</td>
      <td>102</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>American Samoa</td>
      <td>AS</td>
      <td>ASM</td>
      <td>16</td>
      <td>WPR</td>
      <td>2014</td>
      <td>102</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Andorra</td>
      <td>AD</td>
      <td>AND</td>
      <td>20</td>
      <td>EUR</td>
      <td>2014</td>
      <td>102</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <td>Wallis and Futuna Islands</td>
      <td>WF</td>
      <td>WLF</td>
      <td>876</td>
      <td>WPR</td>
      <td>2014</td>
      <td>102</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>West Bank and Gaza Strip</td>
      <td>PS</td>
      <td>PSE</td>
      <td>275</td>
      <td>EMR</td>
      <td>2014</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Yemen</td>
      <td>YE</td>
      <td>YEM</td>
      <td>887</td>
      <td>EMR</td>
      <td>2014</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>41.000000</td>
      <td>29.000000</td>
      <td>1.000000</td>
      <td>6.000000</td>
      <td>3.000000</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Zambia</td>
      <td>ZM</td>
      <td>ZMB</td>
      <td>894</td>
      <td>AFR</td>
      <td>2014</td>
      <td>102</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>68.000000</td>
      <td>35.000000</td>
      <td>1.000000</td>
      <td>11.000000</td>
      <td>20.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>Zimbabwe</td>
      <td>ZW</td>
      <td>ZWE</td>
      <td>716</td>
      <td>AFR</td>
      <td>2014</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>381.000000</td>
      <td>193.000000</td>
      <td>6.000000</td>
      <td>66.000000</td>
      <td>21.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
  </tbody>
</table>
<p>216 rows × 71 columns</p>
</div>




```python
extract014.year.unique()
```




    array([2014], dtype=int64)




```python
count014 = extract014.rep_meth.groupby(extract014.index)
count14 = count014.size()
count14
```




    country
    Afghanistan                  1
    Albania                      1
    Algeria                      1
    American Samoa               1
    Andorra                      1
                                ..
    Wallis and Futuna Islands    1
    West Bank and Gaza Strip     1
    Yemen                        1
    Zambia                       1
    Zimbabwe                     1
    Name: rep_meth, Length: 216, dtype: int64




```python
regions014 = extract014.rep_meth.groupby(extract014.g_whoregion)
regions14 = regions014.size()
regions14
```




    g_whoregion
    AFR    47
    AMR    46
    EMR    22
    EUR    54
    SEA    11
    WPR    36
    Name: rep_meth, dtype: int64




```python
print("In the year",extract014.year.unique(),",",len(count14.index),"Countries were attended to and",len(regions14.index),"Regions were attended to respectively")
```

    In the year [2014] , 216 Countries were attended to and 6 Regions were attended to respectively



```python
extract015 = dataset[dataset.year == 2015]
extract015
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>iso2</th>
      <th>iso3</th>
      <th>iso_numeric</th>
      <th>g_whoregion</th>
      <th>year</th>
      <th>rep_meth</th>
      <th>new_sp_coh</th>
      <th>new_sp_cur</th>
      <th>new_sp_cmplt</th>
      <th>new_sp_died</th>
      <th>...</th>
      <th>mdr_coh</th>
      <th>mdr_succ</th>
      <th>mdr_fail</th>
      <th>mdr_died</th>
      <th>mdr_lost</th>
      <th>xdr_coh</th>
      <th>xdr_succ</th>
      <th>xdr_fail</th>
      <th>xdr_died</th>
      <th>xdr_lost</th>
    </tr>
    <tr>
      <th>country</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>2015</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>83.000000</td>
      <td>53.000000</td>
      <td>0.000000</td>
      <td>14.000000</td>
      <td>16.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>Albania</td>
      <td>AL</td>
      <td>ALB</td>
      <td>8</td>
      <td>EUR</td>
      <td>2015</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>3.000000</td>
      <td>3.000000</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Algeria</td>
      <td>DZ</td>
      <td>DZA</td>
      <td>12</td>
      <td>AFR</td>
      <td>2015</td>
      <td>102</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>American Samoa</td>
      <td>AS</td>
      <td>ASM</td>
      <td>16</td>
      <td>WPR</td>
      <td>2015</td>
      <td>102</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>Andorra</td>
      <td>AD</td>
      <td>AND</td>
      <td>20</td>
      <td>EUR</td>
      <td>2015</td>
      <td>102</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <td>Wallis and Futuna Islands</td>
      <td>WF</td>
      <td>WLF</td>
      <td>876</td>
      <td>WPR</td>
      <td>2015</td>
      <td>102</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>West Bank and Gaza Strip</td>
      <td>PS</td>
      <td>PSE</td>
      <td>275</td>
      <td>EMR</td>
      <td>2015</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Yemen</td>
      <td>YE</td>
      <td>YEM</td>
      <td>887</td>
      <td>EMR</td>
      <td>2015</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>22.000000</td>
      <td>15.000000</td>
      <td>0.000000</td>
      <td>4.000000</td>
      <td>3.000000</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Zambia</td>
      <td>ZM</td>
      <td>ZMB</td>
      <td>894</td>
      <td>AFR</td>
      <td>2015</td>
      <td>102</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>99.000000</td>
      <td>59.000000</td>
      <td>0.000000</td>
      <td>31.000000</td>
      <td>9.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>Zimbabwe</td>
      <td>ZW</td>
      <td>ZWE</td>
      <td>716</td>
      <td>AFR</td>
      <td>2015</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>433.000000</td>
      <td>189.000000</td>
      <td>8.000000</td>
      <td>75.000000</td>
      <td>22.000000</td>
      <td>5.00000</td>
      <td>4.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
    </tr>
  </tbody>
</table>
<p>216 rows × 71 columns</p>
</div>




```python
extract015.year.unique()
```




    array([2015], dtype=int64)




```python
count015 = extract015.rep_meth.groupby(extract015.index)
count15 = count015.size()
count15
```




    country
    Afghanistan                  1
    Albania                      1
    Algeria                      1
    American Samoa               1
    Andorra                      1
                                ..
    Wallis and Futuna Islands    1
    West Bank and Gaza Strip     1
    Yemen                        1
    Zambia                       1
    Zimbabwe                     1
    Name: rep_meth, Length: 216, dtype: int64




```python
regions015 = extract015.rep_meth.groupby(extract015.g_whoregion)
regions15 = regions015.size()
regions15
```




    g_whoregion
    AFR    47
    AMR    46
    EMR    22
    EUR    54
    SEA    11
    WPR    36
    Name: rep_meth, dtype: int64




```python
print("In the year",extract015.year.unique(),",",len(count15.index),"Countries were attended to and",len(regions15.index),"Regions were attended to respectively")
```

    In the year [2015] , 216 Countries were attended to and 6 Regions were attended to respectively



```python
extract016 = dataset[dataset.year == 2016]
extract016
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>iso2</th>
      <th>iso3</th>
      <th>iso_numeric</th>
      <th>g_whoregion</th>
      <th>year</th>
      <th>rep_meth</th>
      <th>new_sp_coh</th>
      <th>new_sp_cur</th>
      <th>new_sp_cmplt</th>
      <th>new_sp_died</th>
      <th>...</th>
      <th>mdr_coh</th>
      <th>mdr_succ</th>
      <th>mdr_fail</th>
      <th>mdr_died</th>
      <th>mdr_lost</th>
      <th>xdr_coh</th>
      <th>xdr_succ</th>
      <th>xdr_fail</th>
      <th>xdr_died</th>
      <th>xdr_lost</th>
    </tr>
    <tr>
      <th>country</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>2016</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>153.000000</td>
      <td>95.000000</td>
      <td>4.000000</td>
      <td>21.000000</td>
      <td>32.000000</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Albania</td>
      <td>AL</td>
      <td>ALB</td>
      <td>8</td>
      <td>EUR</td>
      <td>2016</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>Algeria</td>
      <td>DZ</td>
      <td>DZA</td>
      <td>12</td>
      <td>AFR</td>
      <td>2016</td>
      <td>102</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>American Samoa</td>
      <td>AS</td>
      <td>ASM</td>
      <td>16</td>
      <td>WPR</td>
      <td>2016</td>
      <td>102</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Andorra</td>
      <td>AD</td>
      <td>AND</td>
      <td>20</td>
      <td>EUR</td>
      <td>2016</td>
      <td>102</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <td>Wallis and Futuna Islands</td>
      <td>WF</td>
      <td>WLF</td>
      <td>876</td>
      <td>WPR</td>
      <td>2016</td>
      <td>102</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>West Bank and Gaza Strip</td>
      <td>PS</td>
      <td>PSE</td>
      <td>275</td>
      <td>EMR</td>
      <td>2016</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>Yemen</td>
      <td>YE</td>
      <td>YEM</td>
      <td>887</td>
      <td>EMR</td>
      <td>2016</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>33.000000</td>
      <td>28.000000</td>
      <td>0.000000</td>
      <td>3.000000</td>
      <td>2.000000</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Zambia</td>
      <td>ZM</td>
      <td>ZMB</td>
      <td>894</td>
      <td>AFR</td>
      <td>2016</td>
      <td>102</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>136.000000</td>
      <td>96.000000</td>
      <td>0.000000</td>
      <td>22.000000</td>
      <td>13.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>Zimbabwe</td>
      <td>ZW</td>
      <td>ZWE</td>
      <td>716</td>
      <td>AFR</td>
      <td>2016</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>488.000000</td>
      <td>276.000000</td>
      <td>0.000000</td>
      <td>149.000000</td>
      <td>44.000000</td>
      <td>5.00000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>2.000000</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
<p>216 rows × 71 columns</p>
</div>




```python
extract016.year.unique()
```




    array([2016], dtype=int64)




```python
count016 = extract016.rep_meth.groupby(extract016.index)
count16 = count016.size()
count16
```




    country
    Afghanistan                  1
    Albania                      1
    Algeria                      1
    American Samoa               1
    Andorra                      1
                                ..
    Wallis and Futuna Islands    1
    West Bank and Gaza Strip     1
    Yemen                        1
    Zambia                       1
    Zimbabwe                     1
    Name: rep_meth, Length: 216, dtype: int64




```python
regions016 = extract016.rep_meth.groupby(extract016.g_whoregion)
regions16 = regions016.size()
regions16
```




    g_whoregion
    AFR    47
    AMR    46
    EMR    22
    EUR    54
    SEA    11
    WPR    36
    Name: rep_meth, dtype: int64




```python
print("In the year",extract016.year.unique(),",",len(count16.index),"Countries were attended to and",len(regions16.index),"Regions were attended to respectively")
```

    In the year [2016] , 216 Countries were attended to and 6 Regions were attended to respectively



```python
extract017 = dataset[dataset.year == 2017]
extract017
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>iso2</th>
      <th>iso3</th>
      <th>iso_numeric</th>
      <th>g_whoregion</th>
      <th>year</th>
      <th>rep_meth</th>
      <th>new_sp_coh</th>
      <th>new_sp_cur</th>
      <th>new_sp_cmplt</th>
      <th>new_sp_died</th>
      <th>...</th>
      <th>mdr_coh</th>
      <th>mdr_succ</th>
      <th>mdr_fail</th>
      <th>mdr_died</th>
      <th>mdr_lost</th>
      <th>xdr_coh</th>
      <th>xdr_succ</th>
      <th>xdr_fail</th>
      <th>xdr_died</th>
      <th>xdr_lost</th>
    </tr>
    <tr>
      <th>country</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>2017</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Albania</td>
      <td>AL</td>
      <td>ALB</td>
      <td>8</td>
      <td>EUR</td>
      <td>2017</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Algeria</td>
      <td>DZ</td>
      <td>DZA</td>
      <td>12</td>
      <td>AFR</td>
      <td>2017</td>
      <td>102</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>American Samoa</td>
      <td>AS</td>
      <td>ASM</td>
      <td>16</td>
      <td>WPR</td>
      <td>2017</td>
      <td>102</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Andorra</td>
      <td>AD</td>
      <td>AND</td>
      <td>20</td>
      <td>EUR</td>
      <td>2017</td>
      <td>102</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <td>Wallis and Futuna Islands</td>
      <td>WF</td>
      <td>WLF</td>
      <td>876</td>
      <td>WPR</td>
      <td>2017</td>
      <td>102</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>West Bank and Gaza Strip</td>
      <td>PS</td>
      <td>PSE</td>
      <td>275</td>
      <td>EMR</td>
      <td>2017</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Yemen</td>
      <td>YE</td>
      <td>YEM</td>
      <td>887</td>
      <td>EMR</td>
      <td>2017</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Zambia</td>
      <td>ZM</td>
      <td>ZMB</td>
      <td>894</td>
      <td>AFR</td>
      <td>2017</td>
      <td>102</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
    <tr>
      <td>Zimbabwe</td>
      <td>ZW</td>
      <td>ZWE</td>
      <td>716</td>
      <td>AFR</td>
      <td>2017</td>
      <td>100</td>
      <td>10863.51162</td>
      <td>7887.186906</td>
      <td>964.721656</td>
      <td>430.904174</td>
      <td>...</td>
      <td>334.331807</td>
      <td>182.062827</td>
      <td>30.547632</td>
      <td>55.285032</td>
      <td>52.715739</td>
      <td>25.20448</td>
      <td>8.472963</td>
      <td>4.977812</td>
      <td>7.383028</td>
      <td>2.884202</td>
    </tr>
  </tbody>
</table>
<p>216 rows × 71 columns</p>
</div>




```python
extract017.year.unique()
```




    array([2017], dtype=int64)




```python
count017 = extract017.rep_meth.groupby(extract017.index)
count17 = count017.size()
count17
```




    country
    Afghanistan                  1
    Albania                      1
    Algeria                      1
    American Samoa               1
    Andorra                      1
                                ..
    Wallis and Futuna Islands    1
    West Bank and Gaza Strip     1
    Yemen                        1
    Zambia                       1
    Zimbabwe                     1
    Name: rep_meth, Length: 216, dtype: int64




```python
regions017 = extract017.rep_meth.groupby(extract017.g_whoregion)
regions17 = regions017.size()
regions17
```




    g_whoregion
    AFR    47
    AMR    46
    EMR    22
    EUR    54
    SEA    11
    WPR    36
    Name: rep_meth, dtype: int64




```python
print("In the year",extract017.year.unique(),",",len(count17.index),"Countries were attended to and",len(regions17.index),"Regions were attended to respectively")
```

    In the year [2017] , 216 Countries were attended to and 6 Regions were attended to respectively


### Let's try out some other tricks using the derived country outputs for each year to form a Dataframe. This is just a test of trying out vonsistency skills

### Note that there are other ways to make this happen more efficiently


```python
regions_series = pd.DataFrame({1994: list(regions94.values),
                               1995: list(regions95.values),
                               1996: list(regions96.values),
                               1997: list(regions97.values),
                               1998: list(regions98.values),
                              1999: list(regions99.values),
                              2000: list(regions00.values),
                              2001: list(regions01.values),
                              2002: list(regions02.values),
                              2003: list(regions03.values),
                              2004: list(regions04.values),
                              2005: list(regions05.values),
                              2006: list(regions06.values),
                              2007: list(regions07.values),
                              2008: list(regions08.values),
                              2009: list(regions09.values),
                              2010: list(regions10.values),
                              2011: list(regions11.values),
                              2012: list(regions12.values),
                              2013: list(regions13.values),
                              2014: list(regions14.values),
                              2015: list(regions15.values),
                              2016: list(regions16.values),
                              2017: list(regions17.values)})
```


```python
regions94.index
```




    Index(['AFR', 'AMR', 'EMR', 'EUR', 'SEA', 'WPR'], dtype='object', name='g_whoregion')




```python
new_index = list(regions94.index)
new_index
regions_series.index = new_index
regions_series.index.name = 'who_region'
regions_series.columns.name = "Years"
```


```python
regions_series
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>Years</th>
      <th>1994</th>
      <th>1995</th>
      <th>1996</th>
      <th>1997</th>
      <th>1998</th>
      <th>1999</th>
      <th>2000</th>
      <th>2001</th>
      <th>2002</th>
      <th>2003</th>
      <th>...</th>
      <th>2008</th>
      <th>2009</th>
      <th>2010</th>
      <th>2011</th>
      <th>2012</th>
      <th>2013</th>
      <th>2014</th>
      <th>2015</th>
      <th>2016</th>
      <th>2017</th>
    </tr>
    <tr>
      <th>who_region</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>AFR</td>
      <td>46</td>
      <td>46</td>
      <td>46</td>
      <td>46</td>
      <td>46</td>
      <td>46</td>
      <td>46</td>
      <td>46</td>
      <td>46</td>
      <td>46</td>
      <td>...</td>
      <td>46</td>
      <td>46</td>
      <td>47</td>
      <td>47</td>
      <td>47</td>
      <td>47</td>
      <td>47</td>
      <td>47</td>
      <td>47</td>
      <td>47</td>
    </tr>
    <tr>
      <td>AMR</td>
      <td>44</td>
      <td>44</td>
      <td>44</td>
      <td>44</td>
      <td>44</td>
      <td>44</td>
      <td>44</td>
      <td>44</td>
      <td>44</td>
      <td>44</td>
      <td>...</td>
      <td>44</td>
      <td>46</td>
      <td>46</td>
      <td>46</td>
      <td>46</td>
      <td>46</td>
      <td>46</td>
      <td>46</td>
      <td>46</td>
      <td>46</td>
    </tr>
    <tr>
      <td>EMR</td>
      <td>22</td>
      <td>22</td>
      <td>22</td>
      <td>22</td>
      <td>22</td>
      <td>22</td>
      <td>22</td>
      <td>22</td>
      <td>22</td>
      <td>22</td>
      <td>...</td>
      <td>22</td>
      <td>22</td>
      <td>22</td>
      <td>22</td>
      <td>22</td>
      <td>22</td>
      <td>22</td>
      <td>22</td>
      <td>22</td>
      <td>22</td>
    </tr>
    <tr>
      <td>EUR</td>
      <td>53</td>
      <td>53</td>
      <td>53</td>
      <td>53</td>
      <td>53</td>
      <td>53</td>
      <td>53</td>
      <td>53</td>
      <td>53</td>
      <td>53</td>
      <td>...</td>
      <td>54</td>
      <td>54</td>
      <td>54</td>
      <td>54</td>
      <td>54</td>
      <td>54</td>
      <td>54</td>
      <td>54</td>
      <td>54</td>
      <td>54</td>
    </tr>
    <tr>
      <td>SEA</td>
      <td>10</td>
      <td>10</td>
      <td>10</td>
      <td>10</td>
      <td>10</td>
      <td>10</td>
      <td>10</td>
      <td>10</td>
      <td>11</td>
      <td>11</td>
      <td>...</td>
      <td>11</td>
      <td>11</td>
      <td>11</td>
      <td>11</td>
      <td>11</td>
      <td>11</td>
      <td>11</td>
      <td>11</td>
      <td>11</td>
      <td>11</td>
    </tr>
    <tr>
      <td>WPR</td>
      <td>36</td>
      <td>36</td>
      <td>36</td>
      <td>36</td>
      <td>36</td>
      <td>36</td>
      <td>36</td>
      <td>36</td>
      <td>36</td>
      <td>36</td>
      <td>...</td>
      <td>36</td>
      <td>36</td>
      <td>36</td>
      <td>36</td>
      <td>36</td>
      <td>36</td>
      <td>36</td>
      <td>36</td>
      <td>36</td>
      <td>36</td>
    </tr>
  </tbody>
</table>
<p>6 rows × 24 columns</p>
</div>




```python
regs_series = regions_series.T
regs_series
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>who_region</th>
      <th>AFR</th>
      <th>AMR</th>
      <th>EMR</th>
      <th>EUR</th>
      <th>SEA</th>
      <th>WPR</th>
    </tr>
    <tr>
      <th>Years</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1994</td>
      <td>46</td>
      <td>44</td>
      <td>22</td>
      <td>53</td>
      <td>10</td>
      <td>36</td>
    </tr>
    <tr>
      <td>1995</td>
      <td>46</td>
      <td>44</td>
      <td>22</td>
      <td>53</td>
      <td>10</td>
      <td>36</td>
    </tr>
    <tr>
      <td>1996</td>
      <td>46</td>
      <td>44</td>
      <td>22</td>
      <td>53</td>
      <td>10</td>
      <td>36</td>
    </tr>
    <tr>
      <td>1997</td>
      <td>46</td>
      <td>44</td>
      <td>22</td>
      <td>53</td>
      <td>10</td>
      <td>36</td>
    </tr>
    <tr>
      <td>1998</td>
      <td>46</td>
      <td>44</td>
      <td>22</td>
      <td>53</td>
      <td>10</td>
      <td>36</td>
    </tr>
    <tr>
      <td>1999</td>
      <td>46</td>
      <td>44</td>
      <td>22</td>
      <td>53</td>
      <td>10</td>
      <td>36</td>
    </tr>
    <tr>
      <td>2000</td>
      <td>46</td>
      <td>44</td>
      <td>22</td>
      <td>53</td>
      <td>10</td>
      <td>36</td>
    </tr>
    <tr>
      <td>2001</td>
      <td>46</td>
      <td>44</td>
      <td>22</td>
      <td>53</td>
      <td>10</td>
      <td>36</td>
    </tr>
    <tr>
      <td>2002</td>
      <td>46</td>
      <td>44</td>
      <td>22</td>
      <td>53</td>
      <td>11</td>
      <td>36</td>
    </tr>
    <tr>
      <td>2003</td>
      <td>46</td>
      <td>44</td>
      <td>22</td>
      <td>53</td>
      <td>11</td>
      <td>36</td>
    </tr>
    <tr>
      <td>2004</td>
      <td>46</td>
      <td>44</td>
      <td>22</td>
      <td>52</td>
      <td>11</td>
      <td>36</td>
    </tr>
    <tr>
      <td>2005</td>
      <td>46</td>
      <td>44</td>
      <td>22</td>
      <td>54</td>
      <td>11</td>
      <td>36</td>
    </tr>
    <tr>
      <td>2006</td>
      <td>46</td>
      <td>44</td>
      <td>22</td>
      <td>54</td>
      <td>11</td>
      <td>36</td>
    </tr>
    <tr>
      <td>2007</td>
      <td>46</td>
      <td>44</td>
      <td>22</td>
      <td>54</td>
      <td>11</td>
      <td>36</td>
    </tr>
    <tr>
      <td>2008</td>
      <td>46</td>
      <td>44</td>
      <td>22</td>
      <td>54</td>
      <td>11</td>
      <td>36</td>
    </tr>
    <tr>
      <td>2009</td>
      <td>46</td>
      <td>46</td>
      <td>22</td>
      <td>54</td>
      <td>11</td>
      <td>36</td>
    </tr>
    <tr>
      <td>2010</td>
      <td>47</td>
      <td>46</td>
      <td>22</td>
      <td>54</td>
      <td>11</td>
      <td>36</td>
    </tr>
    <tr>
      <td>2011</td>
      <td>47</td>
      <td>46</td>
      <td>22</td>
      <td>54</td>
      <td>11</td>
      <td>36</td>
    </tr>
    <tr>
      <td>2012</td>
      <td>47</td>
      <td>46</td>
      <td>22</td>
      <td>54</td>
      <td>11</td>
      <td>36</td>
    </tr>
    <tr>
      <td>2013</td>
      <td>47</td>
      <td>46</td>
      <td>22</td>
      <td>54</td>
      <td>11</td>
      <td>36</td>
    </tr>
    <tr>
      <td>2014</td>
      <td>47</td>
      <td>46</td>
      <td>22</td>
      <td>54</td>
      <td>11</td>
      <td>36</td>
    </tr>
    <tr>
      <td>2015</td>
      <td>47</td>
      <td>46</td>
      <td>22</td>
      <td>54</td>
      <td>11</td>
      <td>36</td>
    </tr>
    <tr>
      <td>2016</td>
      <td>47</td>
      <td>46</td>
      <td>22</td>
      <td>54</td>
      <td>11</td>
      <td>36</td>
    </tr>
    <tr>
      <td>2017</td>
      <td>47</td>
      <td>46</td>
      <td>22</td>
      <td>54</td>
      <td>11</td>
      <td>36</td>
    </tr>
  </tbody>
</table>
</div>



### make a visual plot using this DataFrame


```python
regs_series.plot(marker = '*', markersize = 3)
plt.title("Annual Value Variations", alpha = 0.85)
plt.ylabel("Values Per Region", alpha = 0.7, fontstyle = 'italic')
plt.xlabel("Years", alpha = 0.7, fontstyle = 'italic')
plt.legend(ncol = 1, loc = (1.01, 0.59))
```




    <matplotlib.legend.Legend at 0xa00886d0>




![png](output_186_1.png)



```python
champ_data = regs_series.iloc[-11:, 0:3]
champ_data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>who_region</th>
      <th>AFR</th>
      <th>AMR</th>
      <th>EMR</th>
    </tr>
    <tr>
      <th>Years</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>2007</td>
      <td>46</td>
      <td>44</td>
      <td>22</td>
    </tr>
    <tr>
      <td>2008</td>
      <td>46</td>
      <td>44</td>
      <td>22</td>
    </tr>
    <tr>
      <td>2009</td>
      <td>46</td>
      <td>46</td>
      <td>22</td>
    </tr>
    <tr>
      <td>2010</td>
      <td>47</td>
      <td>46</td>
      <td>22</td>
    </tr>
    <tr>
      <td>2011</td>
      <td>47</td>
      <td>46</td>
      <td>22</td>
    </tr>
    <tr>
      <td>2012</td>
      <td>47</td>
      <td>46</td>
      <td>22</td>
    </tr>
    <tr>
      <td>2013</td>
      <td>47</td>
      <td>46</td>
      <td>22</td>
    </tr>
    <tr>
      <td>2014</td>
      <td>47</td>
      <td>46</td>
      <td>22</td>
    </tr>
    <tr>
      <td>2015</td>
      <td>47</td>
      <td>46</td>
      <td>22</td>
    </tr>
    <tr>
      <td>2016</td>
      <td>47</td>
      <td>46</td>
      <td>22</td>
    </tr>
    <tr>
      <td>2017</td>
      <td>47</td>
      <td>46</td>
      <td>22</td>
    </tr>
  </tbody>
</table>
</div>



### Make a visual plot using the concatenated Output as well


```python
champ_data.plot(kind = "bar")
plt.title("Activities Between 2007 to 2017", alpha = 0.85)
plt.legend(ncol = 1, loc = (1.01, 0.77))
plt.ylabel("Number of Countries in Region", alpha = 0.7, fontstyle ='italic')
```




    Text(0, 0.5, 'Number of Countries in Region')




![png](output_189_1.png)



```python
regions_comb = pd.concat([regions94,regions95,regions96,regions97,regions98,regions99,regions00,regions01,regions02,regions03,regions04,regions05,regions06,regions07,regions08,regions09,regions10,regions11,regions12, regions13,regions14,regions15,regions16,regions17], keys =["1994",'1995',"1996","1997","1998","1999","2000","2001","2002","2003","2004","2005","2006","2007","2008","2009","2010","2011","2012","2013","2014","2015","2016","2017"])
regions_comb
```




          g_whoregion
    1994  AFR            46
          AMR            44
          EMR            22
          EUR            53
          SEA            10
                         ..
    2017  AMR            46
          EMR            22
          EUR            54
          SEA            11
          WPR            36
    Name: rep_meth, Length: 144, dtype: int64




```python
region_comb = regions_comb.unstack()
region_comb
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>g_whoregion</th>
      <th>AFR</th>
      <th>AMR</th>
      <th>EMR</th>
      <th>EUR</th>
      <th>SEA</th>
      <th>WPR</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1994</td>
      <td>46</td>
      <td>44</td>
      <td>22</td>
      <td>53</td>
      <td>10</td>
      <td>36</td>
    </tr>
    <tr>
      <td>1995</td>
      <td>46</td>
      <td>44</td>
      <td>22</td>
      <td>53</td>
      <td>10</td>
      <td>36</td>
    </tr>
    <tr>
      <td>1996</td>
      <td>46</td>
      <td>44</td>
      <td>22</td>
      <td>53</td>
      <td>10</td>
      <td>36</td>
    </tr>
    <tr>
      <td>1997</td>
      <td>46</td>
      <td>44</td>
      <td>22</td>
      <td>53</td>
      <td>10</td>
      <td>36</td>
    </tr>
    <tr>
      <td>1998</td>
      <td>46</td>
      <td>44</td>
      <td>22</td>
      <td>53</td>
      <td>10</td>
      <td>36</td>
    </tr>
    <tr>
      <td>1999</td>
      <td>46</td>
      <td>44</td>
      <td>22</td>
      <td>53</td>
      <td>10</td>
      <td>36</td>
    </tr>
    <tr>
      <td>2000</td>
      <td>46</td>
      <td>44</td>
      <td>22</td>
      <td>53</td>
      <td>10</td>
      <td>36</td>
    </tr>
    <tr>
      <td>2001</td>
      <td>46</td>
      <td>44</td>
      <td>22</td>
      <td>53</td>
      <td>10</td>
      <td>36</td>
    </tr>
    <tr>
      <td>2002</td>
      <td>46</td>
      <td>44</td>
      <td>22</td>
      <td>53</td>
      <td>11</td>
      <td>36</td>
    </tr>
    <tr>
      <td>2003</td>
      <td>46</td>
      <td>44</td>
      <td>22</td>
      <td>53</td>
      <td>11</td>
      <td>36</td>
    </tr>
    <tr>
      <td>2004</td>
      <td>46</td>
      <td>44</td>
      <td>22</td>
      <td>52</td>
      <td>11</td>
      <td>36</td>
    </tr>
    <tr>
      <td>2005</td>
      <td>46</td>
      <td>44</td>
      <td>22</td>
      <td>54</td>
      <td>11</td>
      <td>36</td>
    </tr>
    <tr>
      <td>2006</td>
      <td>46</td>
      <td>44</td>
      <td>22</td>
      <td>54</td>
      <td>11</td>
      <td>36</td>
    </tr>
    <tr>
      <td>2007</td>
      <td>46</td>
      <td>44</td>
      <td>22</td>
      <td>54</td>
      <td>11</td>
      <td>36</td>
    </tr>
    <tr>
      <td>2008</td>
      <td>46</td>
      <td>44</td>
      <td>22</td>
      <td>54</td>
      <td>11</td>
      <td>36</td>
    </tr>
    <tr>
      <td>2009</td>
      <td>46</td>
      <td>46</td>
      <td>22</td>
      <td>54</td>
      <td>11</td>
      <td>36</td>
    </tr>
    <tr>
      <td>2010</td>
      <td>47</td>
      <td>46</td>
      <td>22</td>
      <td>54</td>
      <td>11</td>
      <td>36</td>
    </tr>
    <tr>
      <td>2011</td>
      <td>47</td>
      <td>46</td>
      <td>22</td>
      <td>54</td>
      <td>11</td>
      <td>36</td>
    </tr>
    <tr>
      <td>2012</td>
      <td>47</td>
      <td>46</td>
      <td>22</td>
      <td>54</td>
      <td>11</td>
      <td>36</td>
    </tr>
    <tr>
      <td>2013</td>
      <td>47</td>
      <td>46</td>
      <td>22</td>
      <td>54</td>
      <td>11</td>
      <td>36</td>
    </tr>
    <tr>
      <td>2014</td>
      <td>47</td>
      <td>46</td>
      <td>22</td>
      <td>54</td>
      <td>11</td>
      <td>36</td>
    </tr>
    <tr>
      <td>2015</td>
      <td>47</td>
      <td>46</td>
      <td>22</td>
      <td>54</td>
      <td>11</td>
      <td>36</td>
    </tr>
    <tr>
      <td>2016</td>
      <td>47</td>
      <td>46</td>
      <td>22</td>
      <td>54</td>
      <td>11</td>
      <td>36</td>
    </tr>
    <tr>
      <td>2017</td>
      <td>47</td>
      <td>46</td>
      <td>22</td>
      <td>54</td>
      <td>11</td>
      <td>36</td>
    </tr>
  </tbody>
</table>
</div>




```python
region_comb.index.name = "Year"
region_comb.columns.name = "Regions"
region_comb.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>Regions</th>
      <th>AFR</th>
      <th>AMR</th>
      <th>EMR</th>
      <th>EUR</th>
      <th>SEA</th>
      <th>WPR</th>
    </tr>
    <tr>
      <th>Year</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1994</td>
      <td>46</td>
      <td>44</td>
      <td>22</td>
      <td>53</td>
      <td>10</td>
      <td>36</td>
    </tr>
    <tr>
      <td>1995</td>
      <td>46</td>
      <td>44</td>
      <td>22</td>
      <td>53</td>
      <td>10</td>
      <td>36</td>
    </tr>
    <tr>
      <td>1996</td>
      <td>46</td>
      <td>44</td>
      <td>22</td>
      <td>53</td>
      <td>10</td>
      <td>36</td>
    </tr>
    <tr>
      <td>1997</td>
      <td>46</td>
      <td>44</td>
      <td>22</td>
      <td>53</td>
      <td>10</td>
      <td>36</td>
    </tr>
    <tr>
      <td>1998</td>
      <td>46</td>
      <td>44</td>
      <td>22</td>
      <td>53</td>
      <td>10</td>
      <td>36</td>
    </tr>
  </tbody>
</table>
</div>



### Make a visual plot using this output as well


```python
region_comb.plot(marker = "+")
plt.ylabel("Number of Countries in Region", alpha = 0.7, fontstyle ='italic')
plt.xlabel("Years", alpha = 0.7, fontstyle = 'italic')
plt.legend(ncol = 1, loc = (1.01, 0.58))
```




    <matplotlib.legend.Legend at 0x9ff9cfb0>




![png](output_194_1.png)


### Like always, there's no limit to length at which you can unleash and utilize your imagination

### Feel free to do more just as your creativity can take you.

### There's less visual plotting in this lesson, and i believe that leaves you with a huge opportunity to make that a personal task. 

### Make as many visual plots as you deem fit, to build you competence using the Matplotlib Library

### This marks the end of another lesson using Python's amazing Libraries for Data Science / Data Analysis. Be encouraed and let your creativity guide you on this career path. Nerr feel intimidated even if you're doing it a vit poorly. Keep putting in some extra effort. It's just a matter of time before you gain mastery of it

### Till I bring another lesson your way, 

# Happy Learning !!!


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```
